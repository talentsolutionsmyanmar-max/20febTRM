'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { 
  Briefcase, Users, FileText, ArrowDown, Send, Star, Flame, Trophy, Sparkles, Menu, X,
  Check, Building2, CreditCard, Crown, Zap, Target, Award, BookOpen, TrendingUp,
  Globe, Shield, Heart, Cpu, Languages, Megaphone, DollarSign, BarChart3, Rocket, FileEdit,
  Brain, MessageSquare, Wallet, ArrowUpRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const defaultStats = [
  { icon: Briefcase, value: 'Loading...', label: 'Open Positions', labelMm: 'အလုပ်နေရာများ' },
  { icon: Users, value: 'Loading...', label: 'Active Referrers', labelMm: 'ရည်ညွှန်းသူများ' },
  { icon: Building2, value: '50+', label: 'Partner Companies', labelMm: 'မိတ်ဖက်ကုမ္ပဏီများ' },
];

// Trust signals - Company logos
const trustedCompanies = [
  'RK Yangon Steel', 'Universal Energy', 'NielsenIQ Myanmar', 
  'Shwe Taung Htun', 'Sun Myat Tun', 'KBZ Life Insurance'
];

// Testimonials
const testimonials = [
  {
    name: 'Thida A.',
    role: 'HR Professional',
    earned: '960,000 MMK',
    text: 'I earned almost 10 lakhs in just 2 months by referring my network. The platform is super easy to use!',
    textMm: 'နှစ်လအတွင်း ၁၀သိန်းနီးပါး ရရှိခဲ့ပါပြီ။ အသုံးပြုရလွယ်ကူပါတယ်။'
  },
  {
    name: 'Myo K.',
    role: 'Sales Executive',
    earned: '720,000 MMK',
    text: 'Best referral platform in Myanmar. Fast payouts via KPay and great job opportunities.',
    textMm: 'မြန်မာနိုင်ငံ၏ အကောင်းဆုံး referral platform ပါ။ KPay ဖြင့် မြန်မြန်ဆန်ဆန် ပေးချေနိုင်ပါတယ်။'
  },
  {
    name: 'Su L.',
    role: 'University Student',
    earned: '560,000 MMK',
    text: 'As a student, this platform helped me earn while helping my friends find jobs. Win-win!',
    textMm: 'ကျောင်းသားတစ်ဦးအနေဖြင့် သူငယ်ချင်းများကို အလုပ်ရှာပေးရင်း ငွေရရှိခဲ့ပါတယ်။'
  },
];

const features = [
  { icon: Trophy, title: 'Earn Real Money', titleMm: 'ငွေအမှန် ရှာပါ', desc: 'Up to 500,000 MMK per successful referral' },
  { icon: Shield, title: 'Licensed Agency', titleMm: 'လိုင်စင်ရ အေဂျင်စီ', desc: 'Officially registered with Ministry of Labor' },
  { icon: Star, title: 'Referrer Score', titleMm: 'ရည်ညွှန်းသူ ရမှက်', desc: 'Build reputation, unlock exclusive jobs' },
  { icon: Award, title: 'Verified Badges', titleMm: 'အတည်ပြု ဘိတ်ချ်များ', desc: 'Get recognized for your achievements' },
];

// LinkedIn-style Professional Avatars
const professionalAvatars = [
  // Starter (Free)
  { 
    initials: 'JS', 
    name: 'Job Seeker', 
    title: 'Getting Started',
    tier: 'starter', 
    bgColor: 'bg-slate-600',
    borderColor: 'border-slate-500',
    badge: null
  },
  // Professional (5K pts)
  { 
    initials: 'RP', 
    name: 'Referral Pro', 
    title: 'Professional',
    tier: 'professional', 
    bgColor: 'bg-gradient-to-br from-teal-500 to-cyan-600',
    borderColor: 'border-teal-400',
    badge: 'verified'
  },
  // Expert (15K pts)
  { 
    initials: 'EX', 
    name: 'Expert Recruiter', 
    title: 'Expert',
    tier: 'expert', 
    bgColor: 'bg-gradient-to-br from-amber-500 to-yellow-500',
    borderColor: 'border-amber-400',
    badge: 'premium'
  },
  // Master (25K pts)
  { 
    initials: 'MR', 
    name: 'Master Recruiter', 
    title: 'Master',
    tier: 'master', 
    bgColor: 'bg-gradient-to-br from-purple-500 to-pink-500',
    borderColor: 'border-purple-400',
    badge: 'pro'
  },
];

// Referrer Score System - Reputation Capital
const referrerScoreLevels = [
  { 
    min: 80, 
    max: 100, 
    level: 'Elite Recruiter', 
    levelMm: 'ထိပ်တန်း ရည်ညွှန်းသူ',
    access: 'Exclusive high-paying jobs, priority support',
    badge: 'gold',
    color: 'from-amber-400 to-yellow-500'
  },
  { 
    min: 60, 
    max: 79, 
    level: 'Pro Recruiter', 
    levelMm: 'ပရို ရည်ညွှန်းသူ',
    access: 'Standard job access, verified badge',
    badge: 'blue',
    color: 'from-teal-400 to-cyan-500'
  },
  { 
    min: 40, 
    max: 59, 
    level: 'Active Referrer', 
    levelMm: 'တက်ကြွသော ရည်ညွှန်းသူ',
    access: 'Basic job access',
    badge: 'gray',
    color: 'from-slate-400 to-slate-500'
  },
  { 
    min: 0, 
    max: 39, 
    level: 'Newcomer', 
    levelMm: 'အသစ် ရည်ညွှန်းသူ',
    access: 'Limited access, manual review required',
    badge: null,
    color: 'from-slate-600 to-slate-700'
  },
];

// Trust indicators - Updated with Licensed Business
const trustIndicators = [
  { icon: Shield, label: 'Licensed Agency', value: 'Ministry of Labor', sublabel: 'Verified by MOL' },
  { icon: Check, label: 'Successful Placements', value: '200+', sublabel: 'Candidates hired' },
  { icon: DollarSign, label: 'Paid to Referrers', value: '15M+ MMK', sublabel: 'Total bonuses paid' },
  { icon: Award, label: 'Replacement Warranty', value: '60-90 Days', sublabel: 'Free replacement' },
];

// B2B Pricing Plans - Job Posting Slots (NOT guaranteed hires - that's outcome, not what we sell)
const b2bPlans = [
  {
    name: 'Starter',
    nameMm: 'စတင်သူ',
    price: 'Free',
    period: 'Forever',
    slots: '3 Job Slots',
    features: ['3 active job postings', 'Basic job visibility', 'Email support', 'Standard listing', '1 week visibility per post'],
    popular: false,
    color: 'from-slate-500 to-slate-600',
  },
  {
    name: 'Bronze',
    nameMm: 'ကြေးနီ',
    priceMonthly: '150K',
    priceAnnual: '99K',
    period: '/month',
    periodAnnual: '/month (billed annually)',
    slots: '5 Job Slots',
    features: ['5 active job postings', 'Featured job listings', 'Priority support', 'Applicant tracking', 'Company branding', '2 week visibility per post'],
    popular: false,
    color: 'from-amber-600 to-orange-600',
    annualNote: 'Save 34%',
  },
  {
    name: 'Silver',
    nameMm: 'ငွေ',
    priceMonthly: '350K',
    priceAnnual: '299K',
    period: '/month',
    periodAnnual: '/month (billed annually)',
    slots: '15 Job Slots',
    features: ['15 active job postings', 'Premium job listings', 'Dedicated account manager', 'Advanced analytics & reports', 'Bulk job posting', 'Social media promotion', '30 day visibility per post'],
    popular: true,
    color: 'from-gray-400 to-slate-500',
    annualNote: 'Save 14%',
  },
  {
    name: 'Gold',
    nameMm: 'ရွှေ',
    priceMonthly: '950K',
    priceAnnual: '799K',
    period: '/month',
    periodAnnual: '/month (billed annually)',
    slots: 'Unlimited Slots',
    features: ['Unlimited job postings', 'Top of search results', '24/7 priority support', 'Full analytics dashboard', 'Custom branding', 'API access', 'Talent pool access', 'Salary market reports', 'Company profile premium'],
    popular: false,
    color: 'from-yellow-500 to-amber-500',
    annualNote: 'Save 16%',
  },
  {
    name: 'Diamond',
    nameMm: 'စိန်',
    price: 'Custom',
    period: 'Enterprise',
    slots: 'Unlimited+ Priority',
    features: ['Negotiated pricing', 'Everything in Gold', 'White-label solution', 'Custom integrations', 'SLA guarantee', 'Dedicated success team', 'Training sessions', 'Exclusive salary data'],
    popular: false,
    color: 'from-cyan-400 to-teal-500',
  },
];

// Monetization breakdown
const monetizationExample = [
  { reward: '100,000', platform: '20,000', referrer: '80,000' },
  { reward: '200,000', platform: '40,000', referrer: '160,000' },
  { reward: '300,000', platform: '60,000', referrer: '240,000' },
  { reward: '500,000', platform: '100,000', referrer: '400,000' },
];

// Premium plans for users - Affordable for Myanmar market
const userPlans = [
  {
    name: 'Free',
    nameMm: 'အခမဲ့',
    price: '0',
    features: ['Basic job access', 'Limited academy courses', 'Standard referral code', 'Basic avatar'],
    popular: false,
  },
  {
    name: 'Premium',
    nameMm: 'ပရီမီယံ',
    price: '5,000',
    period: 'MMK/month',
    features: ['All job access', 'Full academy access', 'Priority referral matching', 'Premium avatars', 'Double points', 'Early job alerts'],
    popular: true,
  },
  {
    name: 'Pro',
    nameMm: 'ပရို',
    price: '15,000',
    period: 'MMK/month',
    features: ['Everything in Premium', 'Exclusive high-reward jobs', 'Personal referral coach', 'VIP badge', 'Triple points', 'First access to new features', 'Diploma discounts'],
    popular: false,
  },
];

// Job and Lead interfaces
interface Job {
  id: string;
  title: string;
  title_mm?: string;
  company: string;
  location?: string;
  salary?: string;
  reward: number;
  urgent?: boolean;
  skills?: string[];
  level?: string;
}

// Live Jobs Display Component - Shows real jobs from Supabase
function LiveJobsSection() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchJobs() {
      try {
        const res = await fetch('/api/supabase/jobs?limit=8');
        const data = await res.json();
        setJobs(data.jobs || []);
      } catch (error) {
        console.error('Error fetching jobs:', error);
      } finally {
        setLoading(false);
      }
    }
    fetchJobs();
  }, []);

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="glass-card p-5 animate-pulse">
            <div className="h-4 bg-slate-700 rounded w-3/4 mb-3"></div>
            <div className="h-3 bg-slate-700 rounded w-1/2 mb-4"></div>
            <div className="h-6 bg-slate-700 rounded w-full mb-3"></div>
            <div className="flex gap-2">
              <div className="h-5 bg-slate-700 rounded w-16"></div>
              <div className="h-5 bg-slate-700 rounded w-12"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Jobs Grid - Enhanced Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        {jobs.slice(0, 8).map((job, index) => (
          <motion.div
            key={job.id || index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.08 }}
            whileHover={{ y: -6, transition: { duration: 0.2 } }}
            className="relative group cursor-pointer"
          >
            {/* Card Background with gradient border effect */}
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-teal-500/20 via-transparent to-amber-500/10 opacity-0 group-hover:opacity-100 transition-opacity blur-xl" />
            
            <div className="relative glass-card p-0 overflow-hidden rounded-2xl border border-white/5 group-hover:border-teal-500/30 transition-all">
              {/* Top Section - Company Header */}
              <div className="px-5 pt-5 pb-3 bg-gradient-to-b from-slate-800/50 to-transparent">
                {/* Urgent Badge */}
                {job.urgent && (
                  <div className="absolute top-0 right-0">
                    <div className="bg-gradient-to-l from-red-500 to-red-600 text-white text-[10px] font-bold px-3 py-1.5 rounded-bl-xl flex items-center gap-1 shadow-lg">
                      <Flame className="h-3 w-3" />
                      URGENT
                    </div>
                  </div>
                )}
                
                {/* Company Badge */}
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-500/20 to-cyan-500/20 border border-teal-500/20 flex items-center justify-center">
                    <Building2 className="h-5 w-5 text-teal-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-slate-400 text-xs truncate">{job.company}</p>
                    {job.location && (
                      <div className="flex items-center gap-1 text-xs text-slate-500">
                        <Briefcase className="h-3 w-3" />
                        <span className="truncate">{job.location}</span>
                      </div>
                    )}
                  </div>
                </div>
                
                {/* Job Title */}
                <h4 className="font-bold text-white group-hover:text-teal-400 transition-colors text-base mb-1 line-clamp-2 leading-tight">
                  {job.title}
                </h4>
                {job.title_mm && (
                  <p className="text-slate-500 text-xs burmese-text mb-2 line-clamp-1">{job.title_mm}</p>
                )}
              </div>
              
              {/* Middle Section - Salary & Skills */}
              <div className="px-5 py-3 border-y border-white/5 bg-slate-800/20">
                {/* Salary */}
                {job.salary && (
                  <div className="flex items-center gap-2 text-sm mb-2">
                    <span className="text-slate-500">💰</span>
                    <span className="text-slate-200 font-medium">{job.salary}</span>
                  </div>
                )}
                
                {/* Skills Tags */}
                {job.skills && job.skills.length > 0 && (
                  <div className="flex flex-wrap gap-1.5">
                    {job.skills.slice(0, 2).map((skill, i) => (
                      <span 
                        key={i}
                        className="px-2 py-0.5 text-[10px] rounded-full bg-slate-700/50 text-slate-300 border border-slate-600/30"
                      >
                        {skill}
                      </span>
                    ))}
                    {job.skills.length > 2 && (
                      <span className="px-2 py-0.5 text-[10px] rounded-full bg-teal-500/10 text-teal-400 border border-teal-500/20">
                        +{job.skills.length - 2} more
                      </span>
                    )}
                  </div>
                )}
              </div>
              
              {/* Bottom Section - Reward & CTA */}
              <div className="px-5 py-4">
                {/* Reward Display */}
                <div className="flex items-center justify-between mb-4">
                  <div className="text-center">
                    <div className="text-[10px] text-slate-500 uppercase tracking-wide mb-1">Total Reward</div>
                    <div className="text-amber-400 font-bold text-lg">
                      {(job.reward || 0).toLocaleString()}
                      <span className="text-xs text-slate-400 ml-1">MMK</span>
                    </div>
                  </div>
                  <div className="w-px h-10 bg-white/10" />
                  <div className="text-center">
                    <div className="text-[10px] text-slate-500 uppercase tracking-wide mb-1">You Keep</div>
                    <div className="text-teal-400 font-bold text-lg">
                      {Math.round((job.reward || 0) * 0.8).toLocaleString()}
                      <span className="text-xs text-slate-400 ml-1">MMK</span>
                    </div>
                  </div>
                </div>
                
                {/* Refer Button */}
                <Link href="/register">
                  <button className="w-full py-3 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600 text-white text-sm font-medium transition-all flex items-center justify-center gap-2 group-hover:shadow-lg group-hover:shadow-teal-500/25 active:scale-[0.98]">
                    <Send className="h-4 w-4" />
                    Refer & Earn
                    <ArrowUpRight className="h-3.5 w-3.5 ml-0.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </button>
                </Link>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* View All Jobs */}
      <div className="flex justify-center pt-4">
        <Link href="/dashboard/jobs">
          <button className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-gradient-to-r from-slate-800 to-slate-700 border border-white/10 hover:border-teal-500/40 text-slate-200 hover:text-white transition-all shadow-lg hover:shadow-teal-500/10">
            <Briefcase className="h-5 w-5 text-teal-400" />
            <span>View All Available Jobs</span>
            <ArrowUpRight className="h-4 w-4 text-teal-400" />
          </button>
        </Link>
      </div>
    </div>
  );
}

export default function HomePage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'referrer' | 'company'>('referrer');
  const [stats, setStats] = useState(defaultStats);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch real stats from Supabase
  useEffect(() => {
    async function fetchStats() {
      try {
        const response = await fetch('/api/stats');
        const data = await response.json();
        
        if (data.success) {
          setStats([
            { icon: Briefcase, value: `${data.stats.jobs}+`, label: 'Open Positions', labelMm: 'အလုပ်နေရာများ' },
            { icon: Users, value: '150+', label: 'Active Referrers', labelMm: 'ရည်ညွှန်းသူများ' },
            { icon: Building2, value: '50+', label: 'Partner Companies', labelMm: 'မိတ်ဖက်ကုမ္ပဏီများ' },
          ]);
        }
      } catch (error) {
        console.error('Failed to fetch stats:', error);
      } finally {
        setIsLoading(false);
      }
    }
    fetchStats();
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 backdrop-blur-xl bg-slate-900/80 border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="flex flex-col items-start gap-0">
              <div className="flex items-center gap-2">
                <img src="/logo.png" alt="ReferTRM Logo" className="h-10 w-auto rounded-lg" />
                <span className="text-lg font-bold">
                  <span className="text-teal-400">Refer</span>
                  <span className="text-white">TRM</span>
                </span>
              </div>
              <span className="text-[10px] text-teal-400/80 flex items-center gap-1 ml-12">
                Made with <Heart className="w-3 h-3 text-red-400 inline" fill="currentColor" /> in Myanmar <span className="text-slate-500">(မြန်မာပြည်)</span>
              </span>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-6">
              <Link href="/dashboard" className="text-slate-300 hover:text-white transition-colors">Dashboard</Link>
              <Link href="/dashboard/jobs" className="text-slate-300 hover:text-white transition-colors">Jobs</Link>
              <Link href="/dashboard/academy" className="text-slate-300 hover:text-white transition-colors">Academy</Link>
              <Link href="/company" className="text-slate-300 hover:text-white transition-colors">For Companies</Link>
              <Link href="/login" className="btn-primary text-sm">
                Get Started
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="md:hidden text-slate-400">
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="md:hidden bg-slate-900 border-b border-white/5">
            <div className="px-4 py-4 space-y-3">
              <Link href="/dashboard" className="block text-slate-300 hover:text-white">Dashboard</Link>
              <Link href="/dashboard/jobs" className="block text-slate-300 hover:text-white">Jobs</Link>
              <Link href="/dashboard/academy" className="block text-slate-300 hover:text-white">Academy</Link>
              <Link href="/company" className="block text-slate-300 hover:text-white">For Companies</Link>
              <Link href="/login" className="block btn-primary text-center text-sm">Get Started</Link>
            </div>
          </motion.div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-teal-500/20 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl" />
        </div>

        <div className="relative z-10 max-w-5xl mx-auto px-4 text-center">
          {/* Badge */}
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8">
            <span className="w-2 h-2 bg-teal-400 rounded-full animate-pulse" />
            <span className="text-sm text-slate-300">Trusted Referral Hiring Platform for Myanmar</span>
          </motion.div>

          {/* Main Title */}
          <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6">
            <span className="text-gradient-primary">Refer Friends.</span>
            <br />
            <span className="text-gradient-secondary">Earn Rewards.</span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="text-xl text-slate-300 mb-4">
            Earn up to <span className="text-amber-400 font-bold">500,000 MMK</span> per successful referral
          </motion.p>
          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="text-slate-400 mb-2">
            via KPay • Up to 80% to you • Platform takes only 20-30%
          </motion.p>
          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="text-slate-500 burmese-text mb-8">
            သူငယ်ချင်းများကို ရည်ညွှန်းပါ • KPay မှတဆင့် ကျပ် ၅သိန်းထိ ရရှိပါ • ၈၀% သင့်ထံ
          </motion.p>

          {/* CTA Buttons */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link href="/register">
              <Button size="lg" className="btn-primary text-lg px-8 py-6">
                <Briefcase className="mr-2 h-5 w-5" />
                Start Earning Now
              </Button>
            </Link>
            <Link href="/dashboard/jobs">
              <Button size="lg" className="btn-secondary text-lg px-8 py-6">
                <Send className="mr-2 h-5 w-5" />
                Browse Jobs
              </Button>
            </Link>
          </motion.div>

          {/* Trust Stats - Real Data */}
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }} className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-3xl mx-auto">
            {stats.map((stat, index) => (
              <motion.div key={stat.label} initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.7 + index * 0.1 }} className="glass-card p-5 text-center">
                <stat.icon className="h-7 w-7 text-teal-400 mx-auto mb-2" />
                <div className="text-2xl font-bold text-white">{stat.value}</div>
                <div className="text-slate-300 text-sm">{stat.label}</div>
                <div className="text-slate-500 text-xs burmese-text">{stat.labelMm}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Monetization Model Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-slate-900 to-slate-950">
        <div className="max-w-6xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              {activeTab === 'referrer' ? (
                <>
                  <span className="text-white">How You </span>
                  <span className="text-gradient-primary">Earn Money</span>
                </>
              ) : (
                <>
                  <span className="text-white">Access </span>
                  <span className="text-gradient-primary">Top Talent</span>
                  <span className="text-white"> Fast</span>
                </>
              )}
            </h2>
            <p className="text-slate-400 burmese-text">
              {activeTab === 'referrer' 
                ? 'သင်မည်ကဲ့သို့ ငွေရရှိမည်နည်း'
                : 'အရည်အချင်းများကို မြန်ဆန်စွာ ရှာဖွေပါ'}
            </p>
          </motion.div>

          {/* Tab Switcher */}
          <div className="flex justify-center mb-8">
            <div className="inline-flex rounded-xl bg-slate-800 p-1">
              <button
                onClick={() => setActiveTab('referrer')}
                className={`px-6 py-3 rounded-lg font-medium transition-all ${activeTab === 'referrer' ? 'bg-teal-500 text-white' : 'text-slate-400 hover:text-white'}`}
              >
                For Referrers
              </button>
              <button
                onClick={() => setActiveTab('company')}
                className={`px-6 py-3 rounded-lg font-medium transition-all ${activeTab === 'company' ? 'bg-teal-500 text-white' : 'text-slate-400 hover:text-white'}`}
              >
                For Companies
              </button>
            </div>
          </div>

          {activeTab === 'referrer' ? (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
              {/* Revenue Split */}
              <div className="glass-card p-8 text-center">
                <h3 className="text-2xl font-bold text-white mb-6">Revenue Split: You Keep Up to 80%!</h3>
                <p className="text-slate-400 mb-8 burmese-text">ဝင်ငွေခွဲမျူမှု: သင် ၈၀% ထိ ရယူနိုင်သည်!</p>
                
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                  {monetizationExample.map((item, index) => (
                    <div key={index} className="p-4 rounded-xl bg-slate-800/50 border border-white/5">
                      <div className="text-amber-400 font-bold text-lg mb-2">{item.reward} MMK</div>
                      <div className="text-slate-500 text-xs mb-3">Company Reward</div>
                      <div className="flex justify-between text-sm">
                        <div>
                          <div className="text-teal-400 font-bold">{item.referrer}</div>
                          <div className="text-slate-500 text-xs">You (80%)</div>
                        </div>
                        <div>
                          <div className="text-slate-400 font-bold">{item.platform}</div>
                          <div className="text-slate-500 text-xs">Platform (20%)</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-center gap-8 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded bg-teal-500"></div>
                    <span className="text-slate-300">Your Earnings (70-80%)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded bg-slate-600"></div>
                    <span className="text-slate-300">Platform Fee (20-30%)</span>
                  </div>
                </div>
              </div>

              {/* How It Works */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="glass-card p-6 text-center">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-r from-teal-500 to-cyan-500 flex items-center justify-center mx-auto mb-4">
                    <Users className="h-8 w-8 text-white" />
                  </div>
                  <h4 className="text-lg font-bold text-white mb-2">1. Share Jobs</h4>
                  <p className="text-slate-400 text-sm">Share job opportunities with qualified candidates using your referral code</p>
                </div>
                <div className="glass-card p-6 text-center">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 flex items-center justify-center mx-auto mb-4">
                    <Target className="h-8 w-8 text-white" />
                  </div>
                  <h4 className="text-lg font-bold text-white mb-2">2. Candidate Gets Hired</h4>
                  <p className="text-slate-400 text-sm">When your referred candidate successfully gets the job</p>
                </div>
                <div className="glass-card p-6 text-center">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-r from-teal-500 to-cyan-500 flex items-center justify-center mx-auto mb-4">
                    <CreditCard className="h-8 w-8 text-white" />
                  </div>
                  <h4 className="text-lg font-bold text-white mb-2">3. Get Paid!</h4>
                  <p className="text-slate-400 text-sm">Receive up to 80% of the reward directly to your KPay wallet</p>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              {/* Company Pricing */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                {b2bPlans.map((plan, index) => (
                  <div
                    key={index}
                    className={`glass-card p-6 relative ${plan.popular ? 'ring-2 ring-teal-500 scale-105' : ''}`}
                  >
                    {plan.popular && (
                      <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                        <Badge className="bg-teal-500 text-white">Most Popular</Badge>
                      </div>
                    )}
                    {plan.annualNote && (
                      <div className="absolute -top-3 right-2">
                        <Badge className="bg-teal-500/20 text-teal-400 text-xs">{plan.annualNote}</Badge>
                      </div>
                    )}
                    <div className={`text-xl font-bold bg-gradient-to-r ${plan.color} bg-clip-text text-transparent mb-1`}>
                      {plan.name}
                    </div>
                    <div className="text-slate-500 text-xs burmese-text mb-4">{plan.nameMm}</div>
                    
                    {/* Pricing - show annual vs monthly */}
                    {plan.price ? (
                      <div>
                        <div className="text-3xl font-bold text-white mb-1">{plan.price}</div>
                        <div className="text-slate-500 text-sm mb-4">{plan.period}</div>
                      </div>
                    ) : (
                      <div>
                        <div className="flex items-baseline gap-2 mb-1">
                          <span className="text-3xl font-bold text-white">{plan.priceAnnual}</span>
                          <span className="text-slate-500 text-sm line-through">{plan.priceMonthly}</span>
                        </div>
                        <div className="text-teal-400 text-xs mb-2">{plan.periodAnnual}</div>
                        <div className="text-slate-500 text-sm mb-4">or {plan.priceMonthly}{plan.period}</div>
                      </div>
                    )}
                    
                    <div className="text-teal-400 text-sm font-medium mb-4">{plan.slots}</div>
                    <ul className="space-y-2">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-slate-400">
                          <Check className="h-4 w-4 text-teal-400 shrink-0 mt-0.5" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <Link href="/company" className="block mt-6">
                      <Button className={`w-full ${plan.popular ? 'btn-primary' : 'btn-secondary'}`}>
                        Get Started
                      </Button>
                    </Link>
                  </div>
                ))}
              </div>
              
              {/* Annual Pricing Note */}
              <div className="mt-8 text-center">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-teal-500/10 border border-teal-500/20">
                  <Check className="h-4 w-4 text-teal-400" />
                  <span className="text-teal-400 text-sm">Save up to 34% with annual billing</span>
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </section>

      {/* Premium Subscription Section */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-12">
            <Crown className="h-12 w-12 text-amber-400 mx-auto mb-4" />
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="text-white">Premium </span>
              <span className="text-gradient-primary">Membership</span>
            </h2>
            <p className="text-slate-400 burmese-text">အဆင့်မြင့်အသင်းဝင် - ပိုမိုအခွင့်အလမ်းများ</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {userPlans.map((plan, index) => (
              <div
                key={index}
                className={`glass-card p-6 ${plan.popular ? 'ring-2 ring-teal-500 relative' : ''}`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <Badge className="bg-teal-500 text-white">Recommended</Badge>
                  </div>
                )}
                <div className="text-xl font-bold text-white mb-1">{plan.name}</div>
                <div className="text-slate-500 text-xs burmese-text mb-4">{plan.nameMm}</div>
                <div className="flex items-baseline gap-1 mb-4">
                  <span className="text-3xl font-bold text-white">{plan.price}</span>
                  {plan.period && <span className="text-slate-500 text-sm">{plan.period}</span>}
                </div>
                <ul className="space-y-2 mb-6">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-slate-400">
                      <Check className="h-4 w-4 text-teal-400 shrink-0 mt-0.5" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Link href="/register">
                  <Button className={`w-full ${plan.popular ? 'btn-primary' : 'btn-secondary'}`}>
                    {plan.price === '0' ? 'Get Started Free' : 'Subscribe Now'}
                  </Button>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="text-white">Why Choose </span>
              <span className="text-gradient-primary">ReferTRM?</span>
            </h2>
            <p className="text-slate-400 burmese-text">ReferTRM ကို ဘာကြောင့် ရွေးချယ်သင့်သလဲ</p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {features.map((feature, index) => (
              <motion.div key={index} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.1 }}>
                <div className="glass-card p-4 md:p-6 text-center h-full group hover:border-amber-500/30 transition-all">
                  <div className="w-12 h-12 md:w-14 md:h-14 rounded-xl bg-gradient-to-r from-amber-500/20 to-yellow-500/20 flex items-center justify-center mx-auto mb-3 md:mb-4 group-hover:scale-110 transition-transform">
                    <feature.icon className="h-6 w-6 md:h-7 md:w-7 text-amber-400" />
                  </div>
                  <h3 className="text-base md:text-lg font-bold text-white mb-1">{feature.title}</h3>
                  <p className="text-slate-500 text-xs md:text-sm burmese-text mb-2">{feature.titleMm}</p>
                  <p className="text-slate-400 text-xs md:text-sm">{feature.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Referrer Score & Professional Profiles Section */}
      <section className="py-16 md:py-20 px-4 bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900">
        <div className="max-w-6xl mx-auto">
          {/* Referrer Score System */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <Badge className="bg-amber-500/20 text-amber-400 mb-4">📊 Reputation System</Badge>
            <h2 className="text-2xl md:text-4xl font-bold mb-4">
              <span className="text-white">Referrer </span>
              <span className="text-gradient-primary">Score</span>
            </h2>
            <p className="text-slate-400 mb-2">Build your reputation, unlock exclusive opportunities</p>
            <p className="text-slate-500 burmese-text text-sm">သင့်ကျော်ကြားမှုကို တည်ဆောက်ပါ - အထူးအခွင့်အလမ်းများ ရယူပါ</p>
          </motion.div>

          {/* Score Levels */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-12">
            {referrerScoreLevels.map((level, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="glass-card p-6 text-center"
              >
                {/* Score Badge */}
                <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r ${level.color} mb-4`}>
                  {level.badge === 'gold' && <Crown className="h-4 w-4 text-slate-900" />}
                  {level.badge === 'blue' && <Check className="h-4 w-4 text-white" />}
                  <span className="font-bold text-white">{level.min}-{level.max}</span>
                </div>
                
                <h3 className="text-lg font-bold text-white mb-1">{level.level}</h3>
                <p className="text-slate-500 text-xs burmese-text mb-3">{level.levelMm}</p>
                
                {/* Access Level */}
                <div className="p-3 rounded-lg bg-slate-800/50">
                  <p className="text-slate-300 text-sm">{level.access}</p>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Professional Avatar Preview - LinkedIn Style */}
          <div className="glass-card p-6 md:p-8">
            <h3 className="text-xl font-bold text-white mb-6 text-center">
              Professional Profile Levels
              <span className="text-slate-500 text-sm font-normal ml-2">(LinkedIn-style)</span>
            </h3>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {professionalAvatars.map((avatar, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="text-center"
                >
                  {/* Avatar Circle */}
                  <div className="relative inline-block mb-3">
                    <div className={`w-20 h-20 md:w-24 md:h-24 rounded-full ${avatar.bgColor} border-4 ${avatar.borderColor} flex items-center justify-center shadow-xl`}>
                      <span className="text-2xl md:text-3xl font-bold text-white">{avatar.initials}</span>
                    </div>
                    
                    {/* Badge */}
                    {avatar.badge && (
                      <div className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-white flex items-center justify-center shadow-lg">
                        {avatar.badge === 'verified' && <Check className="h-4 w-4 text-teal-500" />}
                        {avatar.badge === 'premium' && <Star className="h-4 w-4 text-amber-500 fill-amber-500" />}
                        {avatar.badge === 'pro' && <Crown className="h-4 w-4 text-amber-500" />}
                      </div>
                    )}
                  </div>
                  
                  <h4 className="text-white font-bold">{avatar.name}</h4>
                  <p className="text-slate-400 text-sm">{avatar.title}</p>
                  
                  {/* Tier Badge */}
                  <Badge className={`mt-2 ${avatar.tier === 'master' ? 'bg-purple-500/20 text-purple-400' : avatar.tier === 'expert' ? 'bg-amber-500/20 text-amber-400' : avatar.tier === 'professional' ? 'bg-teal-500/20 text-teal-400' : 'bg-slate-500/20 text-slate-400'}`}>
                    {avatar.tier.charAt(0).toUpperCase() + avatar.tier.slice(1)}
                  </Badge>
                </motion.div>
              ))}
            </div>
            
            {/* Legend */}
            <div className="mt-8 pt-6 border-t border-white/5">
              <div className="flex flex-wrap justify-center gap-6">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-white flex items-center justify-center">
                    <Check className="h-3 w-3 text-teal-500" />
                  </div>
                  <span className="text-slate-300 text-sm">Verified Badge</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-white flex items-center justify-center">
                    <Star className="h-3 w-3 text-amber-500 fill-amber-500" />
                  </div>
                  <span className="text-slate-300 text-sm">Premium Badge</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-white flex items-center justify-center">
                    <Crown className="h-3 w-3 text-amber-500" />
                  </div>
                  <span className="text-slate-300 text-sm">Pro Badge (Gold)</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Academy Preview Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-slate-950 to-slate-900">
        <div className="max-w-6xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-12">
            <BookOpen className="h-12 w-12 text-teal-400 mx-auto mb-4" />
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="text-white">Learning </span>
              <span className="text-gradient-primary">Academy</span>
            </h2>
            <p className="text-slate-400 burmese-text mb-2">သင်ကြားရေးအကယ်ဒမီ</p>
            <p className="text-slate-500 text-sm">10+ Courses • 80+ Modules • Free Certificates</p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {[
              { name: 'AI & Technology', nameMm: 'AI နှင့်နည်းပညာ', Icon: Cpu, color: 'from-violet-600 to-indigo-600' },
              { name: 'English Language', nameMm: 'အင်္ဂလိပ်ဘာသာ', Icon: Languages, color: 'from-blue-600 to-cyan-600' },
              { name: 'Digital Marketing', nameMm: 'ဒစ်ဂျစ်တယ်မာကeting်ကင်း', Icon: Megaphone, color: 'from-pink-600 to-rose-600' },
              { name: 'Business Skills', nameMm: 'စီးပွားရေးကျွမ်းကျင်မှု', Icon: Briefcase, color: 'from-amber-600 to-orange-600' },
              { name: 'Job Interview', nameMm: 'အလုပ်အင်တာဗျူး', Icon: MessageSquare, color: 'from-emerald-600 to-green-600' },
              { name: 'Financial Literacy', nameMm: 'ဘဏ္ဍာရေးဗဟုသုတ', Icon: Wallet, color: 'from-amber-600 to-yellow-600' },
              { name: 'Microsoft Office', nameMm: 'Microsoft Office', Icon: BarChart3, color: 'from-blue-600 to-indigo-600' },
              { name: 'Entrepreneurship', nameMm: 'စီးပွားရေးလုပ်ငန်း', Icon: Rocket, color: 'from-red-600 to-orange-600' },
              { name: 'Soft Skills', nameMm: 'ဆော့စကီးလ်များ', Icon: Brain, color: 'from-teal-600 to-cyan-600' },
              { name: 'Resume Writing', nameMm: 'Resume ရေးသားခြင်း', Icon: FileEdit, color: 'from-slate-600 to-gray-600' },
            ].map((course, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05 }}
                className="glass-card p-4 text-center hover:border-teal-500/30 transition-all cursor-pointer group"
              >
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${course.color} flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform`}>
                  <course.Icon className="w-6 h-6 text-white" />
                </div>
                <div className="text-sm font-medium text-white">{course.name}</div>
                <div className="text-xs text-slate-500 burmese-text">{course.nameMm}</div>
                <Badge variant="outline" className="mt-2 border-white/10 text-slate-400 text-xs">8 Modules</Badge>
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-teal-500/10 border border-teal-500/20 mb-4">
              <Award className="h-4 w-4 text-teal-400" />
              <span className="text-teal-400 text-sm">100% Free - No hidden fees</span>
            </div>
            <p className="text-slate-400 text-sm mb-4">
              Complete courses to earn certificates • Diploma programs coming soon!
            </p>
            <Link href="/dashboard/academy">
              <Button className="btn-primary">
                <BookOpen className="mr-2 h-4 w-4" />
                Start Learning Free
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Licensed Agency Section */}
      <section className="py-16 px-4 bg-gradient-to-b from-slate-950 to-slate-900">
        <div className="max-w-6xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-12">
            <div className="inline-flex items-center gap-3 px-6 py-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 mb-6">
              <Shield className="h-6 w-6 text-amber-400" />
              <span className="text-amber-400 font-bold">LICENSED RECRUITMENT AGENCY</span>
              <Badge className="bg-green-500/20 text-green-400 text-xs">✓ Verified</Badge>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="text-white">Talent Resources </span>
              <span className="text-gradient-primary">Myanmar (TRM)</span>
            </h2>
            <p className="text-slate-300 text-lg mb-2">Officially Licensed by Ministry of Labor, Myanmar</p>
            <p className="text-slate-500 burmese-text">ဝန်ကြီးဌာနမှ တရားဝင်လိုင်စင်ရ အလုပ်အမှုဆောင်ရွက်ခွင့်လိုင်စင်</p>
          </motion.div>
          
          {/* License Info Card */}
          <div className="glass-card p-6 md:p-8 max-w-4xl mx-auto">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                  <Check className="h-5 w-5 text-green-400" />
                  Why Trust TRM?
                </h3>
                <ul className="space-y-3 text-slate-300">
                  <li className="flex items-start gap-2">
                    <Shield className="h-4 w-4 text-amber-400 mt-1 shrink-0" />
                    <span>Registered with <strong>Ministry of Labor</strong> - verifiable on official government list</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <DollarSign className="h-4 w-4 text-amber-400 mt-1 shrink-0" />
                    <span>Transparent payment via <strong>KPay/Wave Money</strong> with proper receipts</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Award className="h-4 w-4 text-amber-400 mt-1 shrink-0" />
                    <span><strong>Replacement Warranty</strong>: 60-90 days free replacement</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="h-4 w-4 text-amber-400 mt-1 shrink-0" />
                    <span><strong>No scams</strong> - Contract-based, legally binding agreements</span>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-teal-400" />
                  Referral Payment Flow
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-slate-800/50">
                    <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400 font-bold text-sm">1</div>
                    <div className="text-slate-300 text-sm">Client signs contract & pays success fee</div>
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-slate-800/50">
                    <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400 font-bold text-sm">2</div>
                    <div className="text-slate-300 text-sm">Candidate completes probation period</div>
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-slate-800/50">
                    <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400 font-bold text-sm">3</div>
                    <div className="text-slate-300 text-sm">TRM pays referrer bonus (tax absorbed 1st year)</div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Verification Notice */}
            <div className="mt-6 p-4 rounded-xl bg-teal-500/10 border border-teal-500/20 text-center">
              <p className="text-teal-400 text-sm">
                🔐 Verify our license at <strong>Ministry of Labor Official Website</strong> - Search "Talent Resources Myanmar"
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Live Jobs Section - Shows Real Jobs from Supabase */}
      <section className="py-20 px-4 bg-gradient-to-b from-slate-900 to-slate-950">
        <div className="max-w-6xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-12">
            <Briefcase className="h-12 w-12 text-amber-400 mx-auto mb-4" />
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="text-white">Live </span>
              <span className="text-gradient-primary">Job Openings</span>
            </h2>
            <p className="text-slate-400">Real opportunities updated in real-time from our database</p>
          </motion.div>

          <LiveJobsSection />
        </div>
      </section>

      {/* Trust Indicators Section */}
      <section className="py-12 px-4 bg-slate-900/50 border-y border-white/5">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {trustIndicators.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center p-4"
              >
                <item.icon className="h-8 w-8 text-amber-400 mx-auto mb-2" />
                <div className="text-xl md:text-2xl font-bold text-white">{item.value}</div>
                <div className="text-slate-300 text-sm">{item.label}</div>
                <div className="text-slate-500 text-xs">{item.sublabel}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Trusted Companies Section */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-8"
          >
            <p className="text-slate-400 mb-4">Trusted by leading companies in Myanmar</p>
            <p className="text-slate-500 burmese-text text-sm">မြန်မာနိုင်ငံ၏ ထိပ်တန်းကုမ္ပဏီများမှ ယုံကြည်အားထားရသည်</p>
          </motion.div>
          
          <div className="flex flex-wrap justify-center gap-6">
            {trustedCompanies.map((company, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="px-6 py-3 rounded-xl bg-slate-800/50 border border-slate-700 text-slate-300 font-medium"
              >
                {company}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-slate-950 to-slate-900">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="text-white">Success </span>
              <span className="text-gradient-primary">Stories</span>
            </h2>
            <p className="text-slate-400 burmese-text">အောင်မြင်မှုပုံပြင်များ</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="glass-card p-6"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-r from-teal-500 to-cyan-500 flex items-center justify-center text-white font-bold">
                    {testimonial.name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-bold text-white">{testimonial.name}</div>
                    <div className="text-slate-400 text-sm">{testimonial.role}</div>
                  </div>
                </div>
                
                <div className="flex items-center gap-1 mb-3">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-amber-400 fill-amber-400" />
                  ))}
                </div>
                
                <p className="text-slate-300 text-sm mb-2">{testimonial.text}</p>
                <p className="text-slate-500 burmese-text text-xs mb-4">{testimonial.textMm}</p>
                
                <div className="pt-4 border-t border-white/5">
                  <span className="text-teal-400 font-bold">{testimonial.earned}</span>
                  <span className="text-slate-500 text-sm ml-2">earned</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Early Adopter Bonus Section - Addressing Chicken-Egg Problem */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="glass-card p-8 bg-gradient-to-r from-amber-500/10 to-orange-500/10 border-amber-500/20"
          >
            <div className="flex items-start gap-4">
              <div className="w-16 h-16 rounded-full bg-amber-500/20 flex items-center justify-center shrink-0">
                <Zap className="h-8 w-8 text-amber-400" />
              </div>
              <div>
                <Badge className="bg-amber-500/20 text-amber-400 mb-2">Limited Time Offer</Badge>
                <h3 className="text-xl font-bold text-white mb-2">Early Adopter Bonus: First 100 Referrers Get 90%!</h3>
                <p className="text-slate-400 mb-4">
                  Be among the first 100 active referrers and earn <span className="text-amber-400 font-bold">90% of rewards</span> instead of 80%. 
                  That&apos;s an extra 10% bonus on every successful hire!
                </p>
                <p className="text-slate-500 burmese-text text-sm mb-4">
                  ပထမဆုံး ၁၀၀ ဦးသော referrer များအတွက် ၉၀% ဆုကြေးရရှိမည်။
                </p>
                <div className="flex items-center gap-4">
                  <div className="text-sm">
                    <span className="text-slate-400">Spots remaining:</span>
                    <span className="text-amber-400 font-bold ml-2">67/100</span>
                  </div>
                  <Link href="/register">
                    <Button className="btn-primary">
                      Claim Your Spot
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="glass-card p-8 text-center bg-gradient-to-r from-teal-500/10 to-cyan-500/10 border-teal-500/20">
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">Ready to Start Earning?</h2>
            <p className="text-slate-400 mb-6">Join thousands of Myanmar youth building their careers through referrals and learning.</p>
            <p className="text-slate-500 burmese-text mb-8">သင့်အသက်မွေးဝမ်းကြောင်းကို စတင်တည်ဆောက်ပါ။</p>
            <Link href="/register">
              <Button size="lg" className="btn-primary text-lg px-8 py-6">
                Create Free Account
                <ArrowDown className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/5 py-8 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <img src="/logo.png" alt="ReferTRM Logo" className="h-8 w-auto rounded-lg" />
            <span className="font-bold"><span className="text-teal-400">Refer</span><span className="text-white">TRM</span></span>
          </div>
          <p className="text-teal-400 text-sm font-medium flex items-center justify-center gap-1 mb-3">
            Made with <Heart className="w-4 h-4 text-red-400 inline" fill="currentColor" /> in Myanmar <span className="text-slate-400">(မြန်မာပြည်)</span>
          </p>
          <p className="text-slate-500 text-sm mb-2">© 2025 ReferTRM by Talent Solutions Myanmar</p>
          <p className="text-slate-600 text-xs burmese-text">Talent Solutions Myanmar မှ ReferTRM</p>
        </div>
      </footer>
    </div>
  );
}
