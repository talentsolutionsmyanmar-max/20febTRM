export default function XPage() {
  return <div style={{padding:40,background:'#000',color:'#0f0',fontSize:24}}>X PAGE WORKS!</div>
}
