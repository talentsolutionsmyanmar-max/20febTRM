export default function TestPage() {
  return (
    <div style={{ padding: 40, background: '#000', color: '#0f0', minHeight: '100vh' }}>
      <h1>TEST PAGE - STATIC</h1>
      <p>If you see this, routing works fine.</p>
    </div>
  );
}
