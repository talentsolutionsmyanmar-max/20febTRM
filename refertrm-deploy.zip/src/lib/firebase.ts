// Firebase Configuration for ReferTRM
// Initialized with user's Firebase project

import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  signInAnonymously, 
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut, 
  onAuthStateChanged, 
  User as FirebaseUser,
  updateProfile
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc,
  serverTimestamp,
  collection,
  getDocs,
  query,
  where,
  orderBy,
  limit
} from 'firebase/firestore';

// Firebase configuration from environment variables
const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};

// Initialize Firebase only if config is available
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
const auth = getAuth(app);
const db = getFirestore(app);

// User data interface
export interface UserProfile {
  id: string;
  email: string | null;
  phone: string | null;
  name: string | null;
  avatarUrl: string | null;
  avatarType: string;
  avatar: string;
  points: number;
  totalPointsEarned: number;
  streak: number;
  maxStreak: number;
  referralCode: string;
  totalReferrals: number;
  successfulReferrals: number;
  totalEarned: number;
  level: string;
  completedModules: string[];
  purchasedItems: string[];
  lastLoginAt: string | null;
  lastBonusClaim: string | null;
  createdAt: string;
  updatedAt: string;
}

// Generate referral code
function generateReferralCode(): string {
  return 'REF' + Math.random().toString(36).substring(2, 8).toUpperCase();
}

// Create user profile in Firestore
export async function createUserProfile(uid: string, data: Partial<UserProfile> = {}): Promise<void> {
  const userRef = doc(db, 'users', uid);
  const now = new Date().toISOString();
  
  await setDoc(userRef, {
    id: uid,
    email: data.email || null,
    phone: data.phone || null,
    name: data.name || null,
    avatarUrl: data.avatarUrl || null,
    avatarType: data.avatarType || 'neutral',
    avatar: data.avatar || '🧑',
    points: data.points || 50,
    totalPointsEarned: data.totalPointsEarned || 50,
    streak: data.streak || 1,
    maxStreak: data.maxStreak || 1,
    referralCode: data.referralCode || generateReferralCode(),
    totalReferrals: 0,
    successfulReferrals: 0,
    totalEarned: 0,
    level: data.level || 'Amateur',
    completedModules: data.completedModules || [],
    purchasedItems: data.purchasedItems || [],
    lastLoginAt: now,
    lastBonusClaim: null,
    createdAt: now,
    updatedAt: now,
  }, { merge: true });
}

// Get user profile from Firestore
export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  try {
    const userRef = doc(db, 'users', uid);
    const userSnap = await getDoc(userRef);
    
    if (userSnap.exists()) {
      return userSnap.data() as UserProfile;
    }
    return null;
  } catch (error) {
    console.error('Error getting user profile:', error);
    return null;
  }
}

// Update user profile in Firestore
export async function updateUserProfile(uid: string, data: Partial<UserProfile>): Promise<void> {
  const userRef = doc(db, 'users', uid);
  await updateDoc(userRef, {
    ...data,
    updatedAt: new Date().toISOString(),
  });
}

// Register with email and password
export async function registerWithEmail(email: string, password: string, name: string): Promise<FirebaseUser> {
  const result = await createUserWithEmailAndPassword(auth, email, password);
  
  // Update display name
  await updateProfile(result.user, { displayName: name });
  
  // Create user profile in Firestore
  await createUserProfile(result.user.uid, {
    email,
    name,
  });
  
  return result.user;
}

// Sign in with email and password
export async function loginWithEmail(email: string, password: string): Promise<FirebaseUser> {
  const result = await signInWithEmailAndPassword(auth, email, password);
  
  // Update last login
  await updateUserProfile(result.user.uid, {
    lastLoginAt: new Date().toISOString(),
  });
  
  return result.user;
}

// Anonymous sign-in
export async function signInAnonymous(): Promise<FirebaseUser> {
  const result = await signInAnonymously(auth);
  
  // Create user profile
  await createUserProfile(result.user.uid, {
    name: 'Guest User',
  });
  
  return result.user;
}

// Sign out
export async function signOutUser(): Promise<void> {
  await signOut(auth);
}

// Auth state listener
export function onAuthChange(callback: (user: FirebaseUser | null) => void) {
  return onAuthStateChanged(auth, callback);
}

// Get leaderboard from Firestore
export async function getLeaderboard(limitCount: number = 10): Promise<UserProfile[]> {
  const usersRef = collection(db, 'users');
  const q = query(usersRef, orderBy('totalPointsEarned', 'desc'), limit(limitCount));
  const snapshot = await getDocs(q);
  
  return snapshot.docs.map(doc => doc.data() as UserProfile);
}

// Export Firebase instances
export { app, auth, db };
