'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Menu, X, Send, Home, Briefcase, Building2, Users, GraduationCap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const navItems = [
  { label: 'Home', href: '#', labelMm: 'ပင်မစာမျက်နှာ', icon: Home },
  { label: 'Jobs', href: '#jobs', labelMm: 'အလုပ်များ', icon: Briefcase },
  { label: 'Companies', href: '#companies', labelMm: 'ကုမ္ပဏီများ', icon: Building2 },
  { label: 'Refer', href: '#why-refer', labelMm: 'ရည်ညွှန်းပါ', icon: Users },
  { label: 'Academy', href: '#academy', labelMm: 'သင်ကြားရေး', icon: GraduationCap },
];

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('Home');

  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed top-0 left-0 right-0 z-50 backdrop-blur-xl bg-slate-900/80 border-b border-white/5"
    >
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <a href="#" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-500 flex items-center justify-center">
              <span className="text-xl font-bold text-slate-900">R</span>
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-bold leading-none">
                <span className="text-teal-400">TRM</span>{' '}
                <span className="text-white">ReferTRM</span>
              </span>
            </div>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                onClick={() => setActiveTab(item.label)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                  activeTab === item.label
                    ? 'text-teal-400 bg-teal-500/10'
                    : 'text-slate-300 hover:text-white hover:bg-white/5'
                }`}
              >
                {item.label}
              </a>
            ))}
          </nav>

          {/* CTA Button */}
          <div className="hidden md:flex items-center gap-3">
            <Button
              className="btn-teal"
              onClick={() => window.open('https://t.me/ReferTRM', '_blank')}
            >
              <Send className="mr-2 h-4 w-4" />
              Join Telegram
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 text-slate-400 hover:text-white"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Orange Progress Bar */}
        <div className="h-0.5 w-full overflow-hidden">
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: '100%' }}
            transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
            className="h-full w-1/3 bg-gradient-to-r from-transparent via-amber-500 to-transparent"
          />
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="md:hidden bg-slate-900/95 border-b border-white/5"
        >
          <nav className="flex flex-col p-4 gap-2">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                onClick={() => {
                  setActiveTab(item.label);
                  setIsOpen(false);
                }}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 ${
                  activeTab === item.label
                    ? 'text-teal-400 bg-teal-500/10'
                    : 'text-slate-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <item.icon className="h-5 w-5" />
                <div>
                  <div>{item.label}</div>
                  <div className="text-xs text-slate-500 burmese-text">{item.labelMm}</div>
                </div>
              </a>
            ))}
            <Button
              className="btn-teal mt-2"
              onClick={() => window.open('https://t.me/ReferTRM', '_blank')}
            >
              <Send className="mr-2 h-4 w-4" />
              Join Telegram
            </Button>
          </nav>
        </motion.div>
      )}
    </motion.header>
  );
}
