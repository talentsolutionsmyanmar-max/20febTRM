'use client';

import { createContext, useContext, useState, ReactNode, useCallback, useEffect } from 'react';
import { 
  onAuthChange, 
  signInAnonymous, 
  loginWithEmail, 
  registerWithEmail, 
  signOutUser,
  getUserProfile,
  updateUserProfile,
  createUserProfile,
  UserProfile
} from '@/lib/firebase';
import { User as FirebaseUser } from 'firebase/auth';

interface PointTransaction {
  id: string;
  amount: number;
  type: string;
  description: string;
  createdAt: Date;
}

interface User {
  uid: string;
  email: string | null;
  displayName: string | null;
  name: string | null;
  isGuest: boolean;
  points: number;
  totalPointsEarned: number;
  streak: number;
  maxStreak: number;
  completedModules: string[];
  level: string;
  avatar: string;
  avatarType: 'male' | 'female' | 'neutral';
  avatarUrl: string | null;
  referralCode: string;
  totalEarnings: number;
  successfulReferrals: number;
  totalReferrals: number;
  lastLoginAt: string | null;
  lastBonusClaim: string | null;
  purchasedItems: string[];
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  loginAsGuest: () => Promise<void>;
  signup: (email: string, password: string, displayName: string) => Promise<void>;
  logout: () => Promise<void>;
  addPoints: (points: number, reason: string) => void;
  deductPoints: (points: number, reason: string) => boolean;
  completeModule: (moduleId: string, points: number) => void;
  incrementStreak: () => void;
  claimDailyBonus: () => { success: boolean; points: number; message: string };
  purchaseItem: (itemId: string, cost: number) => boolean;
  canClaimDailyBonus: () => boolean;
  getPointTransactions: () => PointTransaction[];
  updateAvatar: (avatarType: 'male' | 'female' | 'neutral', avatar: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const LEVEL_THRESHOLDS = [
  { level: 'Amateur', minPoints: 0, icon: '🌱' },
  { level: 'Professional', minPoints: 300, icon: '💼' },
  { level: 'Expert', minPoints: 600, icon: '⭐' },
  { level: 'Master', minPoints: 1000, icon: '👑' },
];

const STREAK_MILESTONES = [
  { days: 3, bonus: 5 },
  { days: 7, bonus: 10 },
  { days: 14, bonus: 20 },
  { days: 30, bonus: 35 },
  { days: 60, bonus: 50 },
  { days: 100, bonus: 75 },
];

function calculateLevel(points: number): string {
  for (let i = LEVEL_THRESHOLDS.length - 1; i >= 0; i--) {
    if (points >= LEVEL_THRESHOLDS[i].minPoints) {
      return LEVEL_THRESHOLDS[i].level;
    }
  }
  return 'Amateur';
}

function generateId(): string {
  return 'txn_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8);
}

function getSavedTransactions(): PointTransaction[] {
  if (typeof window === 'undefined') return [];
  try {
    const saved = localStorage.getItem('refertrm_transactions');
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (e) {
    console.error('Error reading transactions:', e);
  }
  return [];
}

function convertProfileToUser(profile: UserProfile): User {
  return {
    uid: profile.id,
    email: profile.email,
    displayName: profile.name,
    name: profile.name,
    isGuest: profile.name === 'Guest User',
    points: profile.points,
    totalPointsEarned: profile.totalPointsEarned,
    streak: profile.streak,
    maxStreak: profile.maxStreak,
    completedModules: profile.completedModules || [],
    level: profile.level,
    avatar: profile.avatar || '🧑',
    avatarType: (profile.avatarType as 'male' | 'female' | 'neutral') || 'neutral',
    avatarUrl: profile.avatarUrl,
    referralCode: profile.referralCode,
    totalEarnings: profile.totalEarned || 0,
    successfulReferrals: profile.successfulReferrals || 0,
    totalReferrals: profile.totalReferrals || 0,
    lastLoginAt: profile.lastLoginAt,
    lastBonusClaim: profile.lastBonusClaim,
    purchasedItems: profile.purchasedItems || [],
  };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [transactions, setTransactions] = useState<PointTransaction[]>(() => {
    if (typeof window === 'undefined') return [];
    return getSavedTransactions();
  });
  const [loading, setLoading] = useState(true);

  // Listen to Firebase auth state changes
  useEffect(() => {
    const unsubscribe = onAuthChange(async (firebaseUser: FirebaseUser | null) => {
      if (firebaseUser) {
        // Get user profile from Firestore
        const profile = await getUserProfile(firebaseUser.uid);
        if (profile) {
          setUser(convertProfileToUser(profile));
        } else {
          // Create profile if it doesn't exist
          await createUserProfile(firebaseUser.uid, {
            email: firebaseUser.email,
            name: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'User',
          });
          const newProfile = await getUserProfile(firebaseUser.uid);
          if (newProfile) {
            setUser(convertProfileToUser(newProfile));
          }
        }
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const saveTransactions = useCallback((txns: PointTransaction[]) => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('refertrm_transactions', JSON.stringify(txns));
    }
    setTransactions(txns);
  }, []);

  const addTransaction = useCallback((amount: number, type: string, description: string) => {
    const txn: PointTransaction = {
      id: generateId(),
      amount,
      type,
      description,
      createdAt: new Date(),
    };
    setTransactions(prev => {
      const updated = [txn, ...prev].slice(0, 100);
      if (typeof window !== 'undefined') {
        localStorage.setItem('refertrm_transactions', JSON.stringify(updated));
      }
      return updated;
    });
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    setLoading(true);
    try {
      await loginWithEmail(email, password);
      addTransaction(10, 'login', 'Welcome back!');
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  }, [addTransaction]);

  const loginAsGuest = useCallback(async () => {
    setLoading(true);
    try {
      await signInAnonymous();
    } catch (error) {
      console.error('Guest login error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  }, []);

  const signup = useCallback(async (email: string, password: string, displayName: string) => {
    setLoading(true);
    try {
      await registerWithEmail(email, password, displayName);
      addTransaction(50, 'signup', 'Welcome bonus for creating account!');
    } catch (error) {
      console.error('Signup error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  }, [addTransaction]);

  const logout = useCallback(async () => {
    await signOutUser();
    setUser(null);
  }, []);

  const addPoints = useCallback((points: number, reason: string) => {
    setUser(prevUser => {
      if (!prevUser) return null;
      
      const newPoints = prevUser.points + points;
      const newTotalEarned = prevUser.totalPointsEarned + points;
      const newLevel = calculateLevel(newPoints);
      const updated = { 
        ...prevUser, 
        points: newPoints, 
        totalPointsEarned: newTotalEarned,
        level: newLevel 
      };
      
      // Update in Firestore
      updateUserProfile(prevUser.uid, {
        points: newPoints,
        totalPointsEarned: newTotalEarned,
        level: newLevel,
      });
      
      addTransaction(points, 'earn', reason);
      return updated;
    });
  }, [addTransaction]);

  const deductPoints = useCallback((points: number, reason: string): boolean => {
    let success = false;
    setUser(prevUser => {
      if (!prevUser || prevUser.points < points) return prevUser;
      
      success = true;
      const newPoints = prevUser.points - points;
      const newLevel = calculateLevel(newPoints);
      const updated = { 
        ...prevUser, 
        points: newPoints,
        level: newLevel
      };
      
      updateUserProfile(prevUser.uid, {
        points: newPoints,
        level: newLevel,
      });
      
      addTransaction(-points, 'spend', reason);
      return updated;
    });
    return success;
  }, [addTransaction]);

  const completeModule = useCallback((moduleId: string, points: number) => {
    setUser(prevUser => {
      if (!prevUser || prevUser.completedModules.includes(moduleId)) return prevUser;
      
      const newCompletedModules = [...prevUser.completedModules, moduleId];
      const newPoints = prevUser.points + points;
      const newTotalEarned = prevUser.totalPointsEarned + points;
      const newLevel = calculateLevel(newPoints);
      const updated = { 
        ...prevUser, 
        points: newPoints, 
        totalPointsEarned: newTotalEarned,
        level: newLevel, 
        completedModules: newCompletedModules 
      };
      
      updateUserProfile(prevUser.uid, {
        points: newPoints,
        totalPointsEarned: newTotalEarned,
        level: newLevel,
        completedModules: newCompletedModules,
      });
      
      addTransaction(points, 'module_complete', `Completed module: ${moduleId}`);
      return updated;
    });
  }, [addTransaction]);

  const incrementStreak = useCallback(() => {
    setUser(prevUser => {
      if (!prevUser) return null;
      
      const newStreak = prevUser.streak + 1;
      const newMaxStreak = Math.max(newStreak, prevUser.maxStreak);
      
      let streakBonus = 5;
      for (const milestone of STREAK_MILESTONES) {
        if (newStreak >= milestone.days) {
          streakBonus = milestone.bonus;
        }
      }
      
      const newPoints = prevUser.points + streakBonus;
      const newTotalEarned = prevUser.totalPointsEarned + streakBonus;
      const newLevel = calculateLevel(newPoints);
      const updated = { 
        ...prevUser, 
        streak: newStreak,
        maxStreak: newMaxStreak,
        points: newPoints,
        totalPointsEarned: newTotalEarned,
        level: newLevel
      };
      
      updateUserProfile(prevUser.uid, {
        streak: newStreak,
        maxStreak: newMaxStreak,
        points: newPoints,
        totalPointsEarned: newTotalEarned,
        level: newLevel,
      });
      
      addTransaction(streakBonus, 'streak_bonus', `${newStreak}-day streak bonus!`);
      return updated;
    });
  }, [addTransaction]);

  const canClaimDailyBonus = useCallback((): boolean => {
    if (!user) return false;
    
    const today = new Date().toDateString();
    const lastClaim = user.lastBonusClaim ? new Date(user.lastBonusClaim).toDateString() : null;
    
    return lastClaim !== today;
  }, [user]);

  const claimDailyBonus = useCallback((): { success: boolean; points: number; message: string } => {
    if (!user) {
      return { success: false, points: 0, message: 'Please log in first' };
    }
    
    const today = new Date().toDateString();
    const lastClaim = user.lastBonusClaim ? new Date(user.lastBonusClaim).toDateString() : null;
    
    if (lastClaim === today) {
      return { success: false, points: 0, message: 'Already claimed today!' };
    }
    
    const baseBonus = 10;
    const streakMultiplier = Math.min(user.streak * 0.1, 1);
    const bonus = Math.round(baseBonus * (1 + streakMultiplier));
    
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const wasClaimedYesterday = lastClaim === yesterday.toDateString();
    
    let newStreak: number;
    if (wasClaimedYesterday || !user.lastBonusClaim) {
      newStreak = user.streak + 1;
    } else {
      newStreak = 1;
    }
    
    const newMaxStreak = Math.max(newStreak, user.maxStreak);
    const newPoints = user.points + bonus;
    const newTotalEarned = user.totalPointsEarned + bonus;
    const newLevel = calculateLevel(newPoints);
    
    setUser(prevUser => {
      if (!prevUser) return null;
      
      const updated = { 
        ...prevUser, 
        streak: newStreak,
        maxStreak: newMaxStreak,
        points: newPoints,
        totalPointsEarned: newTotalEarned,
        level: newLevel,
        lastBonusClaim: new Date().toISOString()
      };
      
      updateUserProfile(prevUser.uid, {
        streak: newStreak,
        maxStreak: newMaxStreak,
        points: newPoints,
        totalPointsEarned: newTotalEarned,
        level: newLevel,
        lastBonusClaim: new Date().toISOString(),
      });
      
      addTransaction(bonus, 'daily_bonus', `Daily login bonus (${newStreak}-day streak)`);
      return updated;
    });
    
    return { 
      success: true, 
      points: bonus, 
      message: `+${bonus} points! ${newStreak}-day streak 🔥` 
    };
  }, [user, addTransaction]);

  const purchaseItem = useCallback((itemId: string, cost: number): boolean => {
    let success = false;
    
    setUser(prevUser => {
      if (!prevUser || prevUser.points < cost || prevUser.purchasedItems?.includes(itemId)) {
        return prevUser;
      }
      
      success = true;
      const newPoints = prevUser.points - cost;
      const newLevel = calculateLevel(newPoints);
      const purchasedItems = [...(prevUser.purchasedItems || []), itemId];
      const updated = { 
        ...prevUser, 
        points: newPoints,
        level: newLevel,
        purchasedItems
      };
      
      updateUserProfile(prevUser.uid, {
        points: newPoints,
        level: newLevel,
        purchasedItems,
      });
      
      addTransaction(-cost, 'shop_purchase', `Purchased: ${itemId}`);
      return updated;
    });
    
    return success;
  }, [addTransaction]);

  const getPointTransactions = useCallback((): PointTransaction[] => {
    return transactions;
  }, [transactions]);

  const updateAvatar = useCallback((avatarType: 'male' | 'female' | 'neutral', avatar: string) => {
    setUser(prevUser => {
      if (!prevUser) return null;
      
      const updated = { 
        ...prevUser, 
        avatarType,
        avatar
      };
      
      updateUserProfile(prevUser.uid, {
        avatarType,
        avatar,
      });
      
      return updated;
    });
  }, []);

  return (
    <AuthContext.Provider value={{ 
      user, 
      loading, 
      login, 
      loginAsGuest, 
      signup, 
      logout, 
      addPoints, 
      deductPoints,
      completeModule, 
      incrementStreak,
      claimDailyBonus,
      canClaimDailyBonus,
      purchaseItem,
      getPointTransactions,
      updateAvatar
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}

export { LEVEL_THRESHOLDS, STREAK_MILESTONES };
