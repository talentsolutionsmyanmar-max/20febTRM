'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Users, Briefcase, DollarSign, TrendingUp, BarChart3, Activity, Shield, Settings, LogOut, Crown, Star, Flame } from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const stats = [
  { label: 'Total Users', value: '1,234', change: '+12%', icon: Users, color: 'text-teal-400' },
  { label: 'Active Jobs', value: '56', change: '+5', icon: Briefcase, color: 'text-amber-400' },
  { label: 'Total Referrals', value: '3,456', change: '+23%', icon: TrendingUp, color: 'text-green-400' },
  { label: 'Revenue (MMK)', value: '15.2M', change: '+18%', icon: DollarSign, color: 'text-purple-400' },
];

const recentUsers = [
  { name: 'Thiri Aung', email: 'thiri@email.com', points: 450, level: 'Professional', status: 'active' },
  { name: 'Aung Min', email: 'aung@email.com', points: 320, level: 'Professional', status: 'active' },
  { name: 'Su Myat', email: 'sumyat@email.com', points: 180, level: 'Amateur', status: 'active' },
  { name: 'Zaw Zaw', email: 'zaw@email.com', points: 520, level: 'Expert', status: 'inactive' },
];

export default function AdminDashboard() {
  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white flex items-center gap-2">
              <Shield className="h-6 w-6 text-teal-400" />
              Admin Dashboard
            </h1>
            <p className="text-slate-400">Platform overview and management</p>
          </div>
          <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
            <Crown className="h-3 w-3 mr-1" /> Admin
          </Badge>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat, index) => (
            <motion.div key={stat.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}>
              <Card className="glass-card">
                <CardContent className="p-5">
                  <div className="flex items-center justify-between mb-4">
                    <stat.icon className={`h-8 w-8 ${stat.color}`} />
                    <Badge className="bg-green-500/20 text-green-400 border-green-500/30">{stat.change}</Badge>
                  </div>
                  <div className="text-3xl font-bold text-white">{stat.value}</div>
                  <div className="text-sm text-slate-400">{stat.label}</div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Charts & Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* User Activity Chart */}
          <Card className="glass-card">
            <CardHeader>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Activity className="h-5 w-5 text-teal-400" />
                User Activity
              </h3>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-center justify-center text-slate-500">
                <BarChart3 className="h-16 w-16 text-slate-600" />
                <span className="ml-4">Chart visualization coming soon</span>
              </div>
            </CardContent>
          </Card>

          {/* Recent Users */}
          <Card className="glass-card">
            <CardHeader>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Users className="h-5 w-5 text-teal-400" />
                Recent Users
              </h3>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentUsers.map((user) => (
                  <div key={user.email} className="flex items-center gap-4 p-3 rounded-xl bg-slate-800/30">
                    <div className="avatar avatar-md bg-gradient-to-r from-teal-500 to-cyan-500">
                      {user.name.charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-white">{user.name}</p>
                      <p className="text-xs text-slate-500">{user.email}</p>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-1 text-amber-400 text-sm">
                        <Star className="h-3 w-3" />
                        {user.points}
                      </div>
                      <p className="text-xs text-slate-500">{user.level}</p>
                    </div>
                    <Badge className={user.status === 'active' ? 'badge-success' : 'badge-warning'}>
                      {user.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="glass-card">
          <CardHeader>
            <h3 className="text-lg font-bold text-white">Quick Actions</h3>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: 'Manage Users', icon: Users },
                { label: 'Manage Jobs', icon: Briefcase },
                { label: 'Settings', icon: Settings },
                { label: 'Reports', icon: BarChart3 },
              ].map((action) => (
                <button key={action.label} className="flex flex-col items-center gap-2 p-4 rounded-xl bg-slate-800/30 hover:bg-slate-800/50 transition-colors">
                  <action.icon className="h-6 w-6 text-teal-400" />
                  <span className="text-sm text-slate-300">{action.label}</span>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
