'use client';

import { useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Briefcase, Users, FileText, ArrowDown, Send, Star, Flame, Trophy, Sparkles, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const trustStats = [
  { icon: Briefcase, value: '25+', label: 'Real Open Roles', labelMm: 'အလုပ်နေရာများ' },
  { icon: FileText, value: '1,000+', label: 'CVs Ready', labelMm: 'ကိုယ်ရေးအကျဉ်းများ' },
  { icon: Users, value: '150+', label: 'Active Referrers', labelMm: 'ရည်ညွှန်းသူများ' },
];

const features = [
  { icon: Trophy, title: 'Earn Real Money', titleMm: 'ငွေအမှန် ရှာပါ', desc: 'Up to 500,000 MMK per successful referral' },
  { icon: Star, title: 'Free Learning', titleMm: 'အခမဲ့ သင်ခန်းစာများ', desc: 'Professional courses with certificates' },
  { icon: Flame, title: 'Daily Streak Rewards', titleMm: 'နေ့စဉ် ဆုကြေးများ', desc: 'Login daily to earn bonus points' },
  { icon: Sparkles, title: 'Avatar Customization', titleMm: 'Avatar စိတ်ကြိုက်ပြင်ဆင်မှု', desc: 'Chibi style avatars with premium skins' },
];

export default function HomePage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 backdrop-blur-xl bg-slate-900/80 border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-500 flex items-center justify-center">
                <span className="text-xl font-bold text-slate-900">R</span>
              </div>
              <span className="text-lg font-bold">
                <span className="text-teal-400">Refer</span>
                <span className="text-white">TRM</span>
              </span>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-6">
              <Link href="/dashboard" className="text-slate-300 hover:text-white transition-colors">Dashboard</Link>
              <Link href="/dashboard/jobs" className="text-slate-300 hover:text-white transition-colors">Jobs</Link>
              <Link href="/dashboard/academy" className="text-slate-300 hover:text-white transition-colors">Academy</Link>
              <Link href="/login" className="btn-primary text-sm">
                Get Started
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="md:hidden text-slate-400">
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="md:hidden bg-slate-900 border-b border-white/5">
            <div className="px-4 py-4 space-y-3">
              <Link href="/dashboard" className="block text-slate-300 hover:text-white">Dashboard</Link>
              <Link href="/dashboard/jobs" className="block text-slate-300 hover:text-white">Jobs</Link>
              <Link href="/dashboard/academy" className="block text-slate-300 hover:text-white">Academy</Link>
              <Link href="/login" className="block btn-primary text-center text-sm">Get Started</Link>
            </div>
          </motion.div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-16 overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-teal-500/20 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl" />
        </div>

        <div className="relative z-10 max-w-5xl mx-auto px-4 text-center">
          {/* Badge */}
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8">
            <span className="w-2 h-2 bg-teal-400 rounded-full animate-pulse" />
            <span className="text-sm text-slate-300">Myanmar's #1 Referral Platform</span>
          </motion.div>

          {/* Main Title */}
          <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6">
            <span className="text-gradient-primary">Refer Friends.</span>
            <br />
            <span className="text-gradient-secondary">Earn Rewards.</span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="text-xl text-slate-300 mb-4">
            Earn up to <span className="text-amber-400 font-bold">500,000 MMK</span> per successful referral
          </motion.p>
          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="text-slate-400 mb-2">
            via KPay • 85% to you • Companies pay only 50K flat fee
          </motion.p>
          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="text-slate-500 burmese-text mb-8">
            သူငယ်ချင်းများကို ရည်ညွှန်းပါ • KPay မှတဆင့် ကျပ် ၅သိန်းထိ ရရှိပါ
          </motion.p>

          {/* CTA Buttons */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link href="/register">
              <Button size="lg" className="btn-primary text-lg px-8 py-6">
                <Briefcase className="mr-2 h-5 w-5" />
                Start Earning Now
              </Button>
            </Link>
            <Link href="/dashboard/jobs">
              <Button size="lg" className="btn-secondary text-lg px-8 py-6">
                <Send className="mr-2 h-5 w-5" />
                Browse Jobs
              </Button>
            </Link>
          </motion.div>

          {/* Trust Stats */}
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }} className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-3xl mx-auto">
            {trustStats.map((stat, index) => (
              <motion.div key={stat.label} initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.7 + index * 0.1 }} className="glass-card p-5 text-center">
                <stat.icon className="h-7 w-7 text-teal-400 mx-auto mb-2" />
                <div className="text-2xl font-bold text-white">{stat.value}</div>
                <div className="text-slate-300 text-sm">{stat.label}</div>
                <div className="text-slate-500 text-xs burmese-text">{stat.labelMm}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="text-white">Why Choose </span>
              <span className="text-gradient-primary">ReferTRM?</span>
            </h2>
            <p className="text-slate-400 burmese-text">ReferTRM ကို ဘာကြောင့် ရွေးချယ်သင့်သလဲ</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <motion.div key={index} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.1 }}>
                <div className="glass-card p-6 text-center h-full group hover:border-teal-500/30 transition-all">
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-r from-teal-500/20 to-cyan-500/20 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                    <feature.icon className="h-7 w-7 text-teal-400" />
                  </div>
                  <h3 className="text-lg font-bold text-white mb-1">{feature.title}</h3>
                  <p className="text-slate-500 text-sm burmese-text mb-2">{feature.titleMm}</p>
                  <p className="text-slate-400 text-sm">{feature.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="glass-card p-8 text-center bg-gradient-to-r from-teal-500/10 to-cyan-500/10 border-teal-500/20">
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">Ready to Start Earning?</h2>
            <p className="text-slate-400 mb-6">Join thousands of Myanmar youth building their careers through referrals and learning.</p>
            <p className="text-slate-500 burmese-text mb-8">သင့်အသက်မွေးဝမ်းကြောင်းကို စတင်တည်ဆောက်ပါ။</p>
            <Link href="/register">
              <Button size="lg" className="btn-primary text-lg px-8 py-6">
                Create Free Account
                <ArrowDown className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/5 py-8 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-r from-teal-500 to-cyan-500 flex items-center justify-center">
              <span className="text-sm font-bold text-slate-900">R</span>
            </div>
            <span className="font-bold"><span className="text-teal-400">Refer</span><span className="text-white">TRM</span></span>
          </div>
          <p className="text-slate-500 text-sm mb-2">© 2025 ReferTRM by Talent Solutions Myanmar</p>
          <p className="text-slate-600 text-xs burmese-text">Talent Solutions Myanmar မှ ReferTRM</p>
        </div>
      </footer>
    </div>
  );
}
