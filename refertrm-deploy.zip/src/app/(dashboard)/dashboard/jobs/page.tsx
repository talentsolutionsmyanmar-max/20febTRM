'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Briefcase,
  MapPin,
  Banknote,
  Send,
  Clock,
  Building2,
  Flame,
  Search,
  Share2,
  X,
  Star,
  Users,
  ExternalLink,
  Check,
  AlertCircle,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';

interface Job {
  id: string;
  title: string;
  titleMm?: string;
  company: string;
  location: string;
  salary: string;
  salaryMin?: number;
  salaryMax?: number;
  reward: number;
  skills: string[];
  type: string;
  level: string;
  urgent: boolean;
  posted: string;
  description?: string;
}

// Real job data from Urgent Positions For January.xlsx
const jobs: Job[] = [
  { id: '1', title: 'Senior Supervisor', company: 'RK Yangon Steel', location: 'Thanlyin', salary: '7.5 - 10 Lakhs', salaryMin: 750000, salaryMax: 1000000, reward: 300, skills: ['Leadership', 'Manufacturing', 'Management'], type: 'Full-time', level: 'Senior', urgent: true, posted: '2 days ago' },
  { id: '2', title: 'Warehouse Supervisor', company: 'Universal Energy', location: 'Thingangyun', salary: 'Negotiable', reward: 200, skills: ['Inventory', 'Logistics', 'Team Management'], type: 'Full-time', level: 'Mid', urgent: false, posted: '1 day ago' },
  { id: '3', title: 'Content & Script Writer', company: 'Shwe Taung Htun', location: 'Mingalar Taung Nyunt', salary: '4 - 6 Lakhs', salaryMin: 400000, salaryMax: 600000, reward: 150, skills: ['Content Writing', 'Creative', 'Burmese'], type: 'Full-time', level: 'Mid', urgent: false, posted: '3 days ago' },
  { id: '4', title: 'Site Engineer', company: 'Sun Myat Tun', location: 'Botahtaung', salary: '7.5 Lakhs', salaryMin: 750000, salaryMax: 750000, reward: 250, skills: ['Engineering', 'Construction', 'Civil'], type: 'Full-time', level: 'Senior', urgent: true, posted: '1 day ago' },
  { id: '5', title: 'Data Collector', company: 'NielsenIQ Myanmar', location: 'Mdy, Sagaing, Meikhtila', salary: '3.5 Lakhs', salaryMin: 350000, salaryMax: 350000, reward: 100, skills: ['Data Entry', 'Research', 'Communication'], type: 'Full-time', level: 'Entry', urgent: false, posted: '4 days ago' },
  { id: '6', title: 'Loan Officer', company: 'Real Aid Microfinance', location: 'Ayeyarwady', salary: '4 - 5 Lakhs', salaryMin: 400000, salaryMax: 500000, reward: 150, skills: ['Finance', 'Customer Service', 'Sales'], type: 'Full-time', level: 'Mid', urgent: false, posted: '3 days ago' },
  { id: '7', title: 'Cashier', company: 'Real Aid Microfinance', location: 'Ayeyarwady', salary: 'Above 3 Lakhs', salaryMin: 300000, salaryMax: 400000, reward: 80, skills: ['Cash Handling', 'Customer Service'], type: 'Full-time', level: 'Entry', urgent: false, posted: '5 days ago' },
  { id: '8', title: 'Brand Executive', company: 'Unicharm Myanmar', location: 'Yankin', salary: '7 - 9 Lakhs', salaryMin: 700000, salaryMax: 900000, reward: 250, skills: ['Marketing', 'Brand Management', 'FMCG'], type: 'Full-time', level: 'Mid', urgent: true, posted: '2 days ago' },
  { id: '9', title: 'Assistant Brand Manager', company: 'Unicharm Myanmar', location: 'Yankin', salary: '15 - 17 Lakhs', salaryMin: 1500000, salaryMax: 1700000, reward: 400, skills: ['Brand Strategy', 'Marketing', 'Team Leadership'], type: 'Full-time', level: 'Senior', urgent: true, posted: '1 day ago' },
  { id: '10', title: 'Receptionist', company: 'Myanmar Information Technology', location: 'Insein', salary: '3 - 4 Lakhs', salaryMin: 300000, salaryMax: 400000, reward: 80, skills: ['Communication', 'Microsoft Office', 'Customer Service'], type: 'Full-time', level: 'Entry', urgent: false, posted: '1 week ago' },
  { id: '11', title: 'Assistant Accountant', company: 'KBZ Life Insurance', location: 'Bahan', salary: '4 - 5 Lakhs', salaryMin: 400000, salaryMax: 500000, reward: 150, skills: ['Accounting', 'Excel', 'Financial Reporting'], type: 'Full-time', level: 'Entry', urgent: false, posted: '4 days ago' },
  { id: '12', title: 'Accountant', company: 'Universal Energy', location: 'Thingangyun', salary: '6 - 7 Lakhs', salaryMin: 600000, salaryMax: 700000, reward: 200, skills: ['Accounting', 'Tax', 'Financial Analysis'], type: 'Full-time', level: 'Mid', urgent: false, posted: '3 days ago' },
  { id: '13', title: 'Online Sale', company: 'Salpyar', location: 'North Dagon', salary: '2.4 Lakhs', salaryMin: 240000, salaryMax: 240000, reward: 60, skills: ['E-commerce', 'Sales', 'Social Media'], type: 'Full-time', level: 'Entry', urgent: false, posted: '1 week ago' },
  { id: '14', title: 'Graphic Designer', company: 'WOW Sport', location: 'Kamaryut', salary: 'Around 10 Lakhs', salaryMin: 1000000, salaryMax: 1000000, reward: 250, skills: ['Adobe Creative Suite', 'Design', 'Marketing'], type: 'Full-time', level: 'Mid', urgent: false, posted: '5 days ago' },
  { id: '15', title: 'Senior Sales Executive', company: 'WOW Sport', location: 'Kamaryut', salary: '10 Lakhs', salaryMin: 1000000, salaryMax: 1000000, reward: 280, skills: ['Sales', 'Negotiation', 'Retail'], type: 'Full-time', level: 'Senior', urgent: true, posted: '2 days ago' },
  { id: '16', title: 'Senior Agency Sales Representative', company: 'AMI', location: 'Kamaryut', salary: '5 - 6.5 Lakhs', salaryMin: 500000, salaryMax: 650000, reward: 180, skills: ['Sales', 'Insurance', 'Relationship Building'], type: 'Full-time', level: 'Mid', urgent: false, posted: '4 days ago' },
  { id: '17', title: 'Admin Supervisor', company: 'TOMO', location: 'South Dagon', salary: '5 - 6 Lakhs', salaryMin: 500000, salaryMax: 600000, reward: 170, skills: ['Administration', 'Team Management', 'MS Office'], type: 'Full-time', level: 'Mid', urgent: false, posted: '3 days ago' },
  { id: '18', title: 'IT Supervisor', company: 'Wave Plus', location: 'Mingalardon', salary: '6 Lakhs', salaryMin: 600000, salaryMax: 600000, reward: 200, skills: ['IT Support', 'Network', 'Troubleshooting'], type: 'Full-time', level: 'Mid', urgent: true, posted: '1 day ago' },
  { id: '19', title: 'Sales Staff', company: 'Yangoods', location: 'Pyin Oo Lwin', salary: '2.04 Lakhs', salaryMin: 204000, salaryMax: 204000, reward: 50, skills: ['Sales', 'Customer Service'], type: 'Full-time', level: 'Entry', urgent: false, posted: '1 week ago' },
  { id: '20', title: 'Senior Page Admin', company: 'TOMO', location: 'Tamwe', salary: 'Negotiable', reward: 200, skills: ['Social Media', 'Content', 'Management'], type: 'Full-time', level: 'Senior', urgent: false, posted: '3 days ago' },
  { id: '21', title: 'Junior Page Admin', company: 'TOMO', location: 'Tamwe', salary: '3 - 3.5 Lakhs', salaryMin: 300000, salaryMax: 350000, reward: 90, skills: ['Social Media', 'Content Creation'], type: 'Full-time', level: 'Entry', urgent: false, posted: '4 days ago' },
  { id: '22', title: 'Junior Accountant', company: 'Unicharm Myanmar', location: 'Yankin', salary: '3.5 - 4 Lakhs', salaryMin: 350000, salaryMax: 400000, reward: 100, skills: ['Accounting', 'Excel', 'Data Entry'], type: 'Full-time', level: 'Entry', urgent: false, posted: '5 days ago' },
  { id: '23', title: 'Accountant', company: 'GK International Company', location: 'Kamaryut', salary: '6.5 - 8 Lakhs', salaryMin: 650000, salaryMax: 800000, reward: 220, skills: ['Accounting', 'Tax', 'Financial Reports'], type: 'Full-time', level: 'Mid', urgent: false, posted: '2 days ago' },
  { id: '24', title: 'Assistant Project Coordinator', company: 'GK International Company', location: 'Kamaryut', salary: '3.5 - 5 Lakhs', salaryMin: 350000, salaryMax: 500000, reward: 130, skills: ['Project Management', 'Coordination', 'Communication'], type: 'Full-time', level: 'Entry', urgent: false, posted: '4 days ago' },
  { id: '25', title: 'Interior Designer', company: 'Delight Amatat', location: 'Thingangyun', salary: '10 - 15 Lakhs', salaryMin: 1000000, salaryMax: 1500000, reward: 350, skills: ['Interior Design', 'AutoCAD', '3D Modeling'], type: 'Full-time', level: 'Senior', urgent: true, posted: '1 day ago' },
  { id: '26', title: 'Quantity Surveyor', company: 'Delight Amatat', location: 'Thingangyun', salary: '10 - 15 Lakhs', salaryMin: 1000000, salaryMax: 1500000, reward: 350, skills: ['Quantity Surveying', 'Construction', 'Cost Estimation'], type: 'Full-time', level: 'Senior', urgent: true, posted: '1 day ago' },
];

const levelColors: Record<string, string> = {
  Entry: 'text-green-400 border-green-500/30 bg-green-500/10',
  Mid: 'text-blue-400 border-blue-500/30 bg-blue-500/10',
  Senior: 'text-purple-400 border-purple-500/30 bg-purple-500/10',
};

export default function JobsPage() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [filterLevel, setFilterLevel] = useState<string>('all');
  const [filterUrgent, setFilterUrgent] = useState(false);

  const filteredJobs = jobs.filter(job => {
    const matchesSearch = job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesLevel = filterLevel === 'all' || job.level === filterLevel;
    const matchesUrgent = !filterUrgent || job.urgent;
    return matchesSearch && matchesLevel && matchesUrgent;
  });

  const handleRefer = (job: Job) => {
    const referralCode = user?.referralCode || 'GUEST';
    const message = encodeURIComponent(
      `🎯 *New Referral Opportunity!*\n\n` +
      `📌 Position: ${job.title}\n` +
      `🏢 Company: ${job.company}\n` +
      `📍 Location: ${job.location}\n` +
      `💰 Salary: ${job.salary} MMK\n` +
      `🎁 Referral Reward: ${job.reward}K MMK\n\n` +
      `My Referral Code: ${referralCode}\n\n` +
      `ReferTRM - Myanmar's #1 Referral Platform`
    );
    window.open(`https://t.me/share/url?url=https://refertrm.com/jobs/${job.id}&text=${message}`, '_blank');
  };

  const totalRewards = filteredJobs.reduce((sum, job) => sum + job.reward, 0);

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Briefcase className="h-7 w-7 text-teal-400" />
            Job Listings
          </h1>
          <p className="text-slate-400 burmese-text">အလုပ်နေရာများ - သင့်သူငယ်ချင်းများကို ရည်ညွှန်းပါ</p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <Badge className="bg-teal-500/20 text-teal-400 border-teal-500/30 text-sm">
            <Briefcase className="h-4 w-4 mr-1" />{jobs.length} Open Positions
          </Badge>
          <Badge className="bg-red-500/20 text-red-400 border-red-500/30 text-sm">
            <Flame className="h-4 w-4 mr-1" />{jobs.filter(j => j.urgent).length} Urgent
          </Badge>
          <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30 text-sm">
            <Star className="h-4 w-4 mr-1" />{totalRewards}K Total Rewards
          </Badge>
        </div>
      </div>

      {/* Search & Filters */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-card p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search jobs, companies, locations..."
              className="form-input pl-12 w-full"
            />
          </div>
          <div className="flex gap-2">
            <select
              value={filterLevel}
              onChange={(e) => setFilterLevel(e.target.value)}
              className="form-input px-4 py-2 rounded-xl bg-slate-800 border-white/10 text-white"
            >
              <option value="all">All Levels</option>
              <option value="Entry">Entry Level</option>
              <option value="Mid">Mid Level</option>
              <option value="Senior">Senior Level</option>
            </select>
            <Button
              variant={filterUrgent ? 'default' : 'outline'}
              className={filterUrgent ? 'bg-red-500 text-white' : 'border-white/10'}
              onClick={() => setFilterUrgent(!filterUrgent)}
            >
              <Flame className="h-4 w-4 mr-2" />
              Urgent Only
            </Button>
          </div>
        </div>
      </motion.div>

      {/* Results Count */}
      <div className="flex items-center justify-between">
        <p className="text-slate-400">
          Showing <span className="text-white font-medium">{filteredJobs.length}</span> jobs
        </p>
        <p className="text-slate-500 text-sm">
          Potential earnings: <span className="text-amber-400 font-medium">{filteredJobs.reduce((s, j) => s + j.reward, 0)}K MMK</span>
        </p>
      </div>

      {/* Jobs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredJobs.map((job, index) => (
          <motion.div 
            key={job.id} 
            initial={{ opacity: 0, y: 20 }} 
            animate={{ opacity: 1, y: 0 }} 
            transition={{ delay: index * 0.03 }}
          >
            <Card 
              className="glass-card-hover h-full group cursor-pointer"
              onClick={() => setSelectedJob(job)}
            >
              <CardContent className="p-5">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <h3 className="text-lg font-bold text-white group-hover:text-teal-400 transition-colors truncate">
                        {job.title}
                      </h3>
                      {job.urgent && (
                        <Badge className="bg-red-500/20 text-red-400 border-red-500/30 shrink-0">
                          <Flame className="h-3 w-3 mr-1" />Urgent
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-slate-400 text-sm">
                      <Building2 className="h-4 w-4 shrink-0" />
                      <span className="truncate">{job.company}</span>
                    </div>
                  </div>
                  <Badge className={`shrink-0 ${levelColors[job.level]}`}>
                    {job.level}
                  </Badge>
                </div>

                <div className="flex flex-wrap items-center gap-4 mb-4 text-sm">
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <MapPin className="h-4 w-4 text-teal-400 shrink-0" />
                    <span className="truncate">{job.location}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <Banknote className="h-4 w-4 text-amber-400 shrink-0" />
                    <span>{job.salary} MMK</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-1.5 mb-4">
                  {job.skills.slice(0, 3).map((skill) => (
                    <Badge key={skill} variant="secondary" className="bg-slate-800 text-slate-300 text-xs">
                      {skill}
                    </Badge>
                  ))}
                  {job.skills.length > 3 && (
                    <Badge variant="secondary" className="bg-slate-800 text-slate-500 text-xs">
                      +{job.skills.length - 3}
                    </Badge>
                  )}
                </div>

                <div className="mb-4 p-3 rounded-xl bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/20">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-amber-400 font-bold text-lg">
                        Refer & Earn {job.reward}K MMK
                      </div>
                      <div className="text-slate-500 text-xs">
                        Company pays 50K success fee
                      </div>
                    </div>
                    <div className="text-xs text-slate-500 text-right">
                      <Clock className="h-3 w-3 inline mr-1" />
                      {job.posted}
                    </div>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button 
                    className="flex-1 btn-primary" 
                    onClick={(e) => {
                      e.stopPropagation();
                      handleRefer(job);
                    }}
                  >
                    <Send className="mr-2 h-4 w-4" />Refer Now
                  </Button>
                  <Button 
                    variant="outline" 
                    className="border-white/10"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedJob(job);
                    }}
                  >
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Job Detail Modal */}
      <AnimatePresence>
        {selectedJob && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto"
            onClick={() => setSelectedJob(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-2xl glass-card p-6 bg-slate-900 my-8"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setSelectedJob(null)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white"
              >
                <X className="h-6 w-6" />
              </button>

              {/* Header */}
              <div className="mb-6">
                <div className="flex items-start gap-4">
                  <div className="w-16 h-16 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-500 flex items-center justify-center">
                    <Briefcase className="h-8 w-8 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h2 className="text-2xl font-bold text-white">{selectedJob.title}</h2>
                      {selectedJob.urgent && (
                        <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
                          <Flame className="h-3 w-3 mr-1" />Urgent
                        </Badge>
                      )}
                    </div>
                    <p className="text-slate-400 mt-1">{selectedJob.company}</p>
                    <Badge className={`mt-2 ${levelColors[selectedJob.level]}`}>
                      {selectedJob.level} Level
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Details */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="glass-card p-4">
                  <div className="text-slate-500 text-sm mb-1">Location</div>
                  <div className="text-white flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-teal-400" />
                    {selectedJob.location}
                  </div>
                </div>
                <div className="glass-card p-4">
                  <div className="text-slate-500 text-sm mb-1">Salary</div>
                  <div className="text-white flex items-center gap-2">
                    <Banknote className="h-4 w-4 text-amber-400" />
                    {selectedJob.salary} MMK
                  </div>
                </div>
                <div className="glass-card p-4">
                  <div className="text-slate-500 text-sm mb-1">Job Type</div>
                  <div className="text-white">{selectedJob.type}</div>
                </div>
                <div className="glass-card p-4">
                  <div className="text-slate-500 text-sm mb-1">Posted</div>
                  <div className="text-white">{selectedJob.posted}</div>
                </div>
              </div>

              {/* Skills */}
              <div className="mb-6">
                <h3 className="text-lg font-bold text-white mb-3">Required Skills</h3>
                <div className="flex flex-wrap gap-2">
                  {selectedJob.skills.map((skill) => (
                    <Badge key={skill} className="bg-slate-800 text-white">
                      <Check className="h-3 w-3 mr-1 text-teal-400" />
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Referral Reward */}
              <div className="mb-6 p-4 rounded-xl bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-500/30">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-slate-400 text-sm">Your Referral Reward</div>
                    <div className="text-3xl font-bold text-amber-400">{selectedJob.reward}K MMK</div>
                    <div className="text-slate-500 text-xs mt-1">
                      +{Math.round(selectedJob.reward * 0.15)}K bonus with your referral code
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-slate-500 text-xs">Company Success Fee</div>
                    <div className="text-teal-400 font-medium">50K MMK flat</div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3">
                <Button 
                  className="flex-1 btn-primary text-lg py-6"
                  onClick={() => handleRefer(selectedJob)}
                >
                  <Send className="mr-2 h-5 w-5" />
                  Refer via Telegram
                </Button>
                <Button 
                  variant="outline" 
                  className="border-white/10 px-6"
                  onClick={() => {
                    navigator.clipboard.writeText(
                      `Job: ${selectedJob.title}\nCompany: ${selectedJob.company}\nLocation: ${selectedJob.location}\nSalary: ${selectedJob.salary}\nReferral Code: ${user?.referralCode || 'GUEST'}`
                    );
                  }}
                >
                  <Share2 className="h-5 w-5" />
                </Button>
              </div>

              {/* How It Works */}
              <div className="mt-6 p-4 rounded-xl bg-slate-800/50">
                <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-teal-400" />
                  How Referrals Work
                </h4>
                <ol className="text-slate-400 text-sm space-y-1">
                  <li>1. Share this job with qualified candidates</li>
                  <li>2. They apply using your referral code: <span className="text-teal-400 font-mono">{user?.referralCode || 'GUEST'}</span></li>
                  <li>3. When hired, you earn {selectedJob.reward}K MMK!</li>
                </ol>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
