'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Star,
  Flame,
  Trophy,
  Users,
  BookOpen,
  TrendingUp,
  Gift,
  Zap,
  ChevronRight,
  Target,
  Award,
  Calendar,
  Clock,
  Sparkles,
  Copy,
  Share2,
  ExternalLink,
  Crown,
  Briefcase,
  Check,
  X,
  Building2,
  Settings,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { useAuth, STREAK_MILESTONES } from '@/contexts/AuthContext';

const quickActions = [
  { icon: BookOpen, label: 'Continue Learning', href: '/dashboard/academy', color: 'from-purple-500 to-pink-500' },
  { icon: Briefcase, label: 'Browse Jobs', href: '/dashboard/jobs', color: 'from-teal-500 to-emerald-500' },
  { icon: Users, label: 'Invite Friends', href: '/dashboard/referrals', color: 'from-amber-500 to-orange-500' },
  { icon: Gift, label: 'Redeem Points', href: '/dashboard/rewards', color: 'from-cyan-500 to-blue-500' },
];

const levelColors: Record<string, string> = {
  Amateur: 'text-green-400',
  Professional: 'text-blue-400',
  Expert: 'text-purple-400',
  Master: 'text-amber-400',
};

const levelIcons: Record<string, string> = {
  Amateur: '🌱',
  Professional: '💼',
  Expert: '⭐',
  Master: '👑',
};

export default function DashboardPage() {
  const { user, claimDailyBonus, canClaimDailyBonus, addPoints, incrementStreak } = useAuth();
  const [showDailyBonus, setShowDailyBonus] = useState(false);
  const [copied, setCopied] = useState(false);
  const [bonusResult, setBonusResult] = useState<{ show: boolean; points: number; message: string }>({ show: false, points: 0, message: '' });

  // Check if user can claim daily bonus
  useEffect(() => {
    setShowDailyBonus(canClaimDailyBonus());
  }, [canClaimDailyBonus]);

  const streak = user?.streak || 1;
  const points = user?.points || 0;
  const maxStreak = user?.maxStreak || 1;
  const level = user?.level || 'Amateur';

  // Find next milestone
  const nextMilestone = STREAK_MILESTONES.find(m => m.days > streak) || STREAK_MILESTONES[STREAK_MILESTONES.length - 1];
  const nextBonus = STREAK_MILESTONES.find(m => m.days > streak)?.bonus || 75;

  const handleClaimDaily = () => {
    const result = claimDailyBonus();
    if (result.success) {
      setBonusResult({ show: true, points: result.points, message: result.message });
      setShowDailyBonus(false);
      setTimeout(() => setBonusResult({ show: false, points: 0, message: '' }), 3000);
    }
  };

  const copyReferralCode = () => {
    if (user?.referralCode) {
      navigator.clipboard.writeText(user.referralCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Bonus Notification */}
      <AnimatePresence>
        {bonusResult.show && (
          <motion.div
            initial={{ opacity: 0, y: -50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -50, scale: 0.9 }}
            className="fixed top-20 left-1/2 -translate-x-1/2 z-50 glass-card px-6 py-4 bg-gradient-to-r from-teal-500/20 to-cyan-500/20 border-teal-500/30 shadow-lg"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-teal-500 flex items-center justify-center">
                <Gift className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="text-white font-bold">+{bonusResult.points} Points!</p>
                <p className="text-slate-400 text-sm">{bonusResult.message}</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Welcome Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card p-6"
      >
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="flex items-center gap-5">
            {/* Avatar */}
            <Link href="/dashboard/settings" className="relative group">
              <motion.div 
                className="w-20 h-20 rounded-2xl overflow-hidden border-2 border-teal-500/50 shadow-lg shadow-teal-500/25 group-hover:border-teal-400 transition-colors"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.98 }}
              >
                {user?.avatar?.includes('/') ? (
                  <Image
                    src={user.avatar}
                    alt="Your avatar"
                    width={80}
                    height={80}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-teal-500 to-cyan-500 flex items-center justify-center text-4xl">
                    {user?.avatar || '🧑'}
                  </div>
                )}
              </motion.div>
              <div className="absolute -bottom-2 -right-2 bg-amber-500 rounded-lg px-2 py-1 text-xs font-bold text-slate-900 shadow flex items-center gap-1">
                Lv.{level === 'Amateur' ? 1 : level === 'Professional' ? 2 : level === 'Expert' ? 3 : 4}
              </div>
              <div className="absolute -top-1 -right-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="w-6 h-6 rounded-full bg-slate-800 border border-white/20 flex items-center justify-center">
                  <Settings className="h-3 w-3 text-slate-400" />
                </div>
              </div>
            </Link>

            {/* User Info */}
            <div>
              <h1 className="text-2xl font-bold text-white mb-1">
                Welcome back, {user?.displayName || 'Learner'}! 👋
              </h1>
              <p className="text-slate-400 burmese-text mb-3">
                ကောင်းသောနေ့လေးပါ၊ {user?.displayName || 'သင်'}!
              </p>
              <div className="flex flex-wrap items-center gap-2">
                <Badge className={`${levelColors[level]} bg-white/5 border-current`}>
                  <Crown className="h-3 w-3 mr-1" />
                  {level} {levelIcons[level]}
                </Badge>
                <Badge className="bg-orange-500/20 text-orange-400 border-orange-500/30">
                  <Flame className="h-3 w-3 mr-1" />
                  {streak} Day Streak
                </Badge>
                <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                  <Star className="h-3 w-3 mr-1" />
                  {points.toLocaleString()} pts
                </Badge>
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="flex gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-amber-400">{points.toLocaleString()}</div>
              <div className="text-sm text-slate-400">Points</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-teal-400">{user?.completedModules?.length || 0}</div>
              <div className="text-sm text-slate-400">Modules</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-400">{user?.successfulReferrals || 0}</div>
              <div className="text-sm text-slate-400">Referrals</div>
            </div>
          </div>
        </div>

        {/* Level Progress */}
        <div className="mt-6">
          <div className="flex justify-between text-sm mb-2">
            <span className="text-slate-400">Level Progress</span>
            <span className="text-teal-400">{points} / {level === 'Master' ? '∞' : (level === 'Expert' ? 1000 : level === 'Professional' ? 600 : 300)} XP</span>
          </div>
          <Progress value={level === 'Master' ? 100 : (level === 'Expert' ? ((points - 600) / 400) * 100 : level === 'Professional' ? ((points - 300) / 300) * 100 : (points / 300) * 100)} className="h-3 bg-slate-700" />
        </div>
      </motion.div>

      {/* Daily Bonus CTA */}
      {showDailyBonus && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass-card bg-gradient-to-r from-teal-500/10 to-cyan-500/10 border-teal-500/30"
        >
          <CardContent className="p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-500 flex items-center justify-center animate-pulse">
                <Gift className="h-7 w-7 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Daily Bonus Available!</h3>
                <p className="text-slate-400 text-sm">Claim your daily login reward (+{10 + Math.round(streak * 0.5)} pts)</p>
                <p className="text-slate-500 text-xs burmese-text">နေ့စဉ်အပိုဆုကြေးရယူပါ</p>
              </div>
            </div>
            <Button className="btn-primary" onClick={handleClaimDaily}>
              <Zap className="mr-2 h-4 w-4" />
              Claim Bonus
            </Button>
          </CardContent>
        </motion.div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Points Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="glass-card-hover bg-gradient-to-br from-amber-500/10 to-orange-500/10 border-amber-500/20">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-4">
                <Star className="h-8 w-8 text-amber-400" />
                <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                  <TrendingUp className="h-3 w-3 mr-1" />+{streak > 7 ? '15%' : streak > 3 ? '10%' : '5%'}
                </Badge>
              </div>
              <div className="text-3xl font-bold text-amber-400 mb-1">{points.toLocaleString()}</div>
              <div className="text-sm text-slate-400">Total Points</div>
              <p className="text-xs text-slate-500 mt-2 burmese-text">စုစုပေါင်း အမှတ်များ</p>
            </CardContent>
          </Card>
        </motion.div>

        {/* Streak Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="glass-card-hover bg-gradient-to-br from-orange-500/10 to-red-500/10 border-orange-500/20">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="relative">
                  <Flame className="h-8 w-8 text-orange-400" />
                  <span className="absolute -top-1 -right-1 w-3 h-3 bg-orange-400 rounded-full animate-ping" />
                </div>
                <Badge className="bg-orange-500/20 text-orange-400 border-orange-500/30">
                  🔥 Best: {maxStreak}
                </Badge>
              </div>
              <div className="text-3xl font-bold text-orange-400 mb-1">{streak}</div>
              <div className="text-sm text-slate-400">Day Streak</div>
              <p className="text-xs text-slate-500 mt-2">Next: {nextMilestone.days} days (+{nextBonus} pts)</p>
            </CardContent>
          </Card>
        </motion.div>

        {/* Referrals Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="glass-card-hover bg-gradient-to-br from-green-500/10 to-emerald-500/10 border-green-500/20">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-4">
                <Users className="h-8 w-8 text-green-400" />
                <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                  +15% Bonus
                </Badge>
              </div>
              <div className="text-3xl font-bold text-green-400 mb-1">{user?.totalReferrals || 0}</div>
              <div className="text-sm text-slate-400">Total Referrals</div>
              <p className="text-xs text-green-400 mt-2">
                +{((user?.totalEarnings || 0) / 1000).toFixed(0)}K MMK earned
              </p>
            </CardContent>
          </Card>
        </motion.div>

        {/* Progress Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="glass-card-hover bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/20">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-4">
                <BookOpen className="h-8 w-8 text-purple-400" />
                <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                  {user?.completedModules?.length || 0}/24
                </Badge>
              </div>
              <div className="text-3xl font-bold text-purple-400 mb-1">{user?.completedModules?.length || 0}</div>
              <div className="text-sm text-slate-400">Modules Done</div>
              <Progress value={((user?.completedModules?.length || 0) / 24) * 100} className="h-1.5 mt-3 bg-slate-700" />
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Streak & Referral */}
        <div className="lg:col-span-2 space-y-6">
          {/* Streak Progress */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card className="glass-card">
              <CardHeader className="pb-2">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Flame className="h-5 w-5 text-orange-400" />
                  Streak Milestones
                </h3>
                <p className="text-slate-500 text-sm burmese-text">စည်းကမ်း ထူးခြားချက်များ</p>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3 overflow-x-auto pb-2">
                  {STREAK_MILESTONES.map((milestone, index) => {
                    const isCompleted = streak >= milestone.days;
                    const isCurrent = streak < milestone.days && (STREAK_MILESTONES[index - 1]?.days || 0) <= streak;
                    
                    return (
                      <motion.div
                        key={milestone.days}
                        whileHover={{ scale: 1.05 }}
                        className={`flex-shrink-0 w-20 h-24 rounded-xl flex flex-col items-center justify-center relative ${
                          isCompleted
                            ? 'bg-gradient-to-br from-orange-500 to-red-500 shadow-lg shadow-orange-500/25'
                            : isCurrent
                            ? 'bg-orange-500/20 border-2 border-orange-500/50'
                            : 'bg-slate-800/50'
                        }`}
                      >
                        {isCompleted && (
                          <div className="absolute -top-2 -right-2">
                            <Trophy className="h-5 w-5 text-amber-300" />
                          </div>
                        )}
                        <span className={`text-2xl font-bold ${
                          isCompleted ? 'text-white' : 'text-slate-400'
                        }`}>
                          {milestone.days}
                        </span>
                        <span className="text-xs text-slate-300">days</span>
                        <span className={`text-xs mt-1 ${
                          isCompleted ? 'text-amber-200' : 'text-slate-500'
                        }`}>
                          +{milestone.bonus} pts
                        </span>
                      </motion.div>
                    );
                  })}
                </div>
                <p className="text-slate-400 text-sm mt-4">
                  🎯 <span className="text-teal-400">{nextMilestone.days - streak} more days</span> to unlock +{nextBonus} bonus points!
                </p>
              </CardContent>
            </Card>
          </motion.div>

          {/* Referral Code */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <Card className="glass-card bg-gradient-to-r from-teal-500/10 to-cyan-500/10 border-teal-500/20">
              <CardHeader className="pb-2">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Share2 className="h-5 w-5 text-teal-400" />
                  Share & Earn
                </h3>
                <p className="text-slate-500 text-sm burmese-text">မျှဝေပြီး ရယူပါ</p>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1">
                    <p className="text-sm text-slate-400 mb-2">Your unique referral code</p>
                    <div className="flex items-center gap-2">
                      <code className="flex-1 px-4 py-3 bg-slate-800/50 rounded-xl text-teal-400 font-mono text-lg">
                        {user?.referralCode || 'REFABC12'}
                      </code>
                      <Button
                        variant="outline"
                        className="border-white/10"
                        onClick={copyReferralCode}
                      >
                        {copied ? <Check className="h-4 w-4 text-green-400" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                    <p className="text-xs text-slate-500 mt-2">
                      You earn <span className="text-amber-400">+15% permanent bonus</span> on every successful referral!
                    </p>
                  </div>
                  <div className="flex flex-col gap-2">
                    <Button className="btn-primary">
                      <ExternalLink className="mr-2 h-4 w-4" />
                      Share on Telegram
                    </Button>
                    <Button variant="outline" className="border-white/10">
                      <Share2 className="mr-2 h-4 w-4" />
                      Copy Link
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Quick Access to New Features */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
          >
            <Card className="glass-card">
              <CardHeader className="pb-2">
                <h3 className="text-lg font-bold text-white">Explore Features</h3>
              </CardHeader>
              <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <Link href="/dashboard/leaderboard">
                  <div className="p-4 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-colors cursor-pointer text-center">
                    <Trophy className="h-6 w-6 text-amber-400 mx-auto mb-2" />
                    <span className="text-sm text-white">Leaderboard</span>
                    <p className="text-xs text-slate-500">300K MMK Prize</p>
                  </div>
                </Link>
                <Link href="/dashboard/companies">
                  <div className="p-4 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-colors cursor-pointer text-center">
                    <Building2 className="h-6 w-6 text-teal-400 mx-auto mb-2" />
                    <span className="text-sm text-white">Companies</span>
                    <p className="text-xs text-slate-500">Reviews & Salaries</p>
                  </div>
                </Link>
                <Link href="/dashboard/community">
                  <div className="p-4 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-colors cursor-pointer text-center">
                    <Users className="h-6 w-6 text-purple-400 mx-auto mb-2" />
                    <span className="text-sm text-white">Community</span>
                    <p className="text-xs text-slate-500">Forums & Meetups</p>
                  </div>
                </Link>
                <Link href="/dashboard/jobs">
                  <div className="p-4 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-colors cursor-pointer text-center">
                    <Briefcase className="h-6 w-6 text-green-400 mx-auto mb-2" />
                    <span className="text-sm text-white">Jobs</span>
                    <p className="text-xs text-slate-500">26 Open Positions</p>
                  </div>
                </Link>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Right Column - Quick Actions */}
        <div className="space-y-6">
          {/* Quick Actions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
          >
            <Card className="glass-card">
              <CardHeader className="pb-2">
                <h3 className="text-lg font-bold text-white">Quick Actions</h3>
              </CardHeader>
              <CardContent className="grid grid-cols-2 gap-3">
                {quickActions.map((action, index) => (
                  <Link key={index} href={action.href}>
                    <Button
                      variant="outline"
                      className="w-full h-auto py-4 flex-col gap-2 border-white/5 hover:border-white/20 bg-slate-800/30"
                    >
                      <div className={`w-10 h-10 rounded-xl bg-gradient-to-r ${action.color} flex items-center justify-center`}>
                        <action.icon className="h-5 w-5 text-white" />
                      </div>
                      <span className="text-xs text-slate-300">{action.label}</span>
                    </Button>
                  </Link>
                ))}
              </CardContent>
            </Card>
          </motion.div>

          {/* Monthly Prize Pool */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 }}
          >
            <Card className="glass-card bg-gradient-to-r from-amber-500/10 to-orange-500/10 border-amber-500/20">
              <CardContent className="p-5 text-center">
                <Trophy className="h-8 w-8 text-amber-400 mx-auto mb-2" />
                <div className="text-2xl font-bold text-amber-400 mb-1">300,000 MMK</div>
                <div className="text-sm text-slate-400">Monthly Prize Pool</div>
                <p className="text-xs text-slate-500 mt-2 burmese-text">လစဉ်ဆုကြေး</p>
                <Link href="/dashboard/leaderboard">
                  <Button className="mt-4 btn-primary w-full" size="sm">
                    View Leaderboard
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
