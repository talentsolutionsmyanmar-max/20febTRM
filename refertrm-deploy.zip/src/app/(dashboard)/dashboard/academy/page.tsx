'use client';

import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, Users, MessageSquare, TrendingUp, BookOpen, Target, Award, Play, Lock, Check, X, Download, Share2, Crown, Sparkles, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface Module {
  id: string;
  title: string;
  titleMm: string;
  duration: string;
  points: number;
  status: 'locked' | 'available' | 'in_progress' | 'completed';
  content?: string;
}

interface Track {
  id: string;
  icon: React.ElementType;
  title: string;
  titleMm: string;
  description: string;
  modules: Module[];
  totalPoints: number;
  color: string;
  level: string;
}

interface ConfettiParticle {
  id: number;
  x: number;
  y: number;
  color: string;
  delay: number;
  size: number;
}

const tracks: Track[] = [
  {
    id: 'ai-resilient',
    icon: Brain,
    title: 'AI-Resilient Career Skills',
    titleMm: 'AI-ခံနိုင်ရည် အသက်မွေးဝမ်းကြောင်း ကျွမ်းကျင်မှုများ',
    description: 'Learn skills that will remain valuable in the AI era',
    color: 'from-purple-500 to-pink-500',
    level: 'Intermediate',
    totalPoints: 400,
    modules: [
      { id: 'ai-1', title: 'Understanding AI Impact', titleMm: 'AI သက်ရောက်မှုကို နားလည်ခြင်း', duration: '15 min', points: 50, status: 'completed' },
      { id: 'ai-2', title: 'Critical Thinking', titleMm: 'ဝေဖန်တွေးခေါ်မှု', duration: '20 min', points: 60, status: 'completed' },
      { id: 'ai-3', title: 'Emotional Intelligence', titleMm: 'စိတ်ခံစားမှု ဉာဏ်ရည်', duration: '25 min', points: 70, status: 'in_progress' },
      { id: 'ai-4', title: 'Creative Problem Solving', titleMm: 'ဖန်တီးရေး ပြဿနာဖြေရှင်းမှု', duration: '30 min', points: 80, status: 'available' },
    ],
  },
  {
    id: 'recruitment',
    icon: Users,
    title: 'Recruitment Mastery',
    titleMm: 'အလုပ်စုံရှာဖွေရေး ကျွမ်းကျင်မှု',
    description: 'Master the art of finding and placing top talent',
    color: 'from-teal-500 to-emerald-500',
    level: 'Beginner',
    totalPoints: 300,
    modules: [
      { id: 'rec-1', title: 'Introduction to Recruitment', titleMm: 'အလုပ်စုံရှာဖွေရေး မိတ်ဆက်', duration: '10 min', points: 30, status: 'completed' },
      { id: 'rec-2', title: 'Sourcing Candidates', titleMm: 'ကိုယ်စားလှယ်များ ရှာဖွေခြင်း', duration: '20 min', points: 50, status: 'in_progress' },
      { id: 'rec-3', title: 'Screening & Interviewing', titleMm: 'စစ်ဆေးမှုနှင့် အင်တာဗျူး', duration: '25 min', points: 60, status: 'locked' },
    ],
  },
  {
    id: 'sales',
    icon: TrendingUp,
    title: 'Sales & Marketing',
    titleMm: 'အရောင်းနှင့် မာကတ်တင်း',
    description: 'Learn to promote jobs and attract candidates',
    color: 'from-blue-500 to-indigo-500',
    level: 'Intermediate',
    totalPoints: 250,
    modules: [
      { id: 'sales-1', title: 'Sales Fundamentals', titleMm: 'အရောင်းအခြေခံများ', duration: '15 min', points: 40, status: 'available' },
      { id: 'sales-2', title: 'Digital Marketing', titleMm: 'ဒစ်ဂျစ်တယ် မာကတ်တင်း', duration: '20 min', points: 50, status: 'locked' },
    ],
  },
  {
    id: 'communication',
    icon: MessageSquare,
    title: 'Communication Skills',
    titleMm: 'ဆက်သွယ်ရေး ကျွမ်းကျင်မှုများ',
    description: 'Build rapport with candidates and companies',
    color: 'from-amber-500 to-orange-500',
    level: 'Beginner',
    totalPoints: 200,
    modules: [
      { id: 'com-1', title: 'Professional Communication', titleMm: 'ပရော်ဖက်ရှင်နယ် ဆက်သွယ်ရေး', duration: '10 min', points: 30, status: 'available' },
    ],
  },
  {
    id: 'english',
    icon: BookOpen,
    title: 'English for Job Seekers',
    titleMm: 'အလုပ်ရှာဖွေသူများအတွက် အင်္ဂလိပ်စာ',
    description: 'Improve your English for better opportunities',
    color: 'from-green-500 to-teal-500',
    level: 'Beginner',
    totalPoints: 350,
    modules: [
      { id: 'eng-1', title: 'Basic Business English', titleMm: 'အခြေခံ စီးပွားရေး အင်္ဂလိပ်စာ', duration: '20 min', points: 50, status: 'available' },
    ],
  },
];

export default function AcademyPage() {
  const { toast } = useToast();
  const { completeModule, addPoints } = useAuth();
  const [selectedTrack, setSelectedTrack] = useState<Track | null>(null);
  const [selectedModule, setSelectedModule] = useState<Module | null>(null);
  const [showCelebration, setShowCelebration] = useState(false);
  const [confetti, setConfetti] = useState<ConfettiParticle[]>([]);
  const [completedModuleInfo, setCompletedModuleInfo] = useState<{ title: string; points: number } | null>(null);
  const [tracksState, setTracksState] = useState<Track[]>(tracks);

  // Generate confetti particles
  const generateConfetti = useCallback(() => {
    const colors = ['#14b8a6', '#f59e0b', '#8b5cf6', '#ec4899', '#10b981', '#3b82f6'];
    const particles: ConfettiParticle[] = [];
    for (let i = 0; i < 50; i++) {
      particles.push({
        id: i,
        x: Math.random() * 100,
        y: Math.random() * 100,
        color: colors[Math.floor(Math.random() * colors.length)],
        delay: Math.random() * 0.5,
        size: Math.random() * 10 + 5,
      });
    }
    setConfetti(particles);
    return particles;
  }, []);

  const handleModuleComplete = (moduleId: string, moduleTitle: string, points: number) => {
    // Update local state
    setTracksState(prevTracks => 
      prevTracks.map(track => ({
        ...track,
        modules: track.modules.map(mod => {
          if (mod.id === moduleId) {
            return { ...mod, status: 'completed' };
          }
          // Unlock next module in the same track
          if (mod.status === 'locked') {
            const currentModuleIndex = track.modules.findIndex(m => m.id === moduleId);
            const thisModuleIndex = track.modules.findIndex(m => m.id === mod.id);
            if (thisModuleIndex === currentModuleIndex + 1) {
              return { ...mod, status: 'available' };
            }
          }
          return mod;
        }),
      }))
    );

    // Update selected module if open
    if (selectedModule?.id === moduleId) {
      setSelectedModule(prev => prev ? { ...prev, status: 'completed' } : null);
    }

    // Add points via context
    addPoints(points, `Completed module: ${moduleTitle}`);

    // Show celebration
    setCompletedModuleInfo({ title: moduleTitle, points });
    generateConfetti();
    setShowCelebration(true);

    setTimeout(() => {
      setShowCelebration(false);
      setConfetti([]);
      setCompletedModuleInfo(null);
    }, 3000);

    toast({
      title: 'Module Completed! 🎉',
      description: `You earned ${points} points for completing "${moduleTitle}"`,
    });
  };

  const getTrackProgress = (track: Track) => {
    const completed = track.modules.filter(m => m.status === 'completed').length;
    return Math.round((completed / track.modules.length) * 100);
  };

  const totalModules = tracksState.reduce((sum, t) => sum + t.modules.length, 0);
  const completedModules = tracksState.reduce((sum, t) => sum + t.modules.filter(m => m.status === 'completed').length, 0);

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Learning Academy</h1>
          <p className="text-slate-400 burmese-text">သင်ကြားရေး အကယ်ဒမီ</p>
        </div>
        <div className="flex items-center gap-3">
          <Badge className="bg-teal-500/20 text-teal-400 border-teal-500/30">
            <BookOpen className="h-3 w-3 mr-1" />{tracks.length} Tracks
          </Badge>
          <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
            <Award className="h-3 w-3 mr-1" />{completedModules}/{totalModules} Completed
          </Badge>
        </div>
      </div>

      {/* Stats */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="glass-card p-4 text-center">
          <div className="text-2xl font-bold text-teal-400">{tracks.length}</div>
          <div className="text-sm text-slate-400">Learning Tracks</div>
        </Card>
        <Card className="glass-card p-4 text-center">
          <div className="text-2xl font-bold text-amber-400">{totalModules}</div>
          <div className="text-sm text-slate-400">Total Modules</div>
        </Card>
        <Card className="glass-card p-4 text-center">
          <div className="text-2xl font-bold text-purple-400">{tracks.reduce((s, t) => s + t.totalPoints, 0)}</div>
          <div className="text-sm text-slate-400">Total Points</div>
        </Card>
        <Card className="glass-card p-4 text-center">
          <div className="text-2xl font-bold text-green-400">{completedModules}</div>
          <div className="text-sm text-slate-400">Completed</div>
        </Card>
      </motion.div>

      {/* Tracks Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {tracksState.map((track, index) => {
          const progress = getTrackProgress(track);
          const completedCount = track.modules.filter(m => m.status === 'completed').length;
          
          return (
            <motion.div key={track.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}>
              <Card className="glass-card-hover h-full group cursor-pointer" onClick={() => setSelectedTrack(track)}>
                <CardContent className="p-5">
                  <div className="flex items-start gap-4 mb-4">
                    <div className={`w-14 h-14 rounded-xl bg-gradient-to-r ${track.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                      <track.icon className="h-7 w-7 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-white group-hover:text-teal-400 transition-colors">{track.title}</h3>
                      <p className="text-slate-500 text-sm burmese-text">{track.titleMm}</p>
                      <Badge variant="outline" className={`mt-2 border-${track.level === 'Beginner' ? 'green' : 'amber'}-500/50 text-${track.level === 'Beginner' ? 'green' : 'amber'}-400`}>{track.level}</Badge>
                    </div>
                  </div>
                  
                  <p className="text-slate-400 text-sm mb-4">{track.description}</p>
                  
                  <div className="mb-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-slate-400"><BookOpen className="h-4 w-4 inline mr-1" />{completedCount}/{track.modules.length} modules</span>
                      <span className="text-sm text-teal-400">{progress}%</span>
                    </div>
                    <Progress value={progress} className="h-2 bg-slate-700" />
                  </div>
                  
                  <div className="flex items-center justify-between text-sm text-slate-500">
                    <span className="flex items-center gap-1"><Target className="h-4 w-4" />{track.modules.length} modules</span>
                    <span className="flex items-center gap-1 text-amber-400"><Award className="h-4 w-4" />+{track.totalPoints} pts</span>
                  </div>
                  
                  <Button className={`w-full mt-4 ${progress > 0 ? 'btn-primary' : 'btn-outline'}`}>
                    {progress === 100 ? <><Check className="mr-2 h-4 w-4" />Completed</> : progress > 0 ? <><Play className="mr-2 h-4 w-4" />Continue</> : <><Play className="mr-2 h-4 w-4" />Start Track</>}
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Track Detail Modal */}
      <AnimatePresence>
        {selectedTrack && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="relative w-full max-w-2xl glass-card p-6 bg-slate-900 my-8">
              <button onClick={() => setSelectedTrack(null)} className="absolute top-4 right-4 text-slate-400 hover:text-white"><X className="h-6 w-6" /></button>
              
              <div className="flex items-center gap-4 mb-6">
                <div className={`w-16 h-16 rounded-xl bg-gradient-to-r ${selectedTrack.color} flex items-center justify-center`}>
                  <selectedTrack.icon className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white">{selectedTrack.title}</h2>
                  <p className="text-slate-500 burmese-text">{selectedTrack.titleMm}</p>
                </div>
              </div>
              
              <div className="space-y-3 mb-6">
                {selectedTrack.modules.map((module, index) => (
                  <motion.div 
                    key={module.id} 
                    className={`glass-card p-4 flex items-center gap-4 ${module.status === 'locked' ? 'opacity-50' : 'cursor-pointer hover:border-teal-500/50'}`}
                    whileHover={module.status !== 'locked' ? { scale: 1.01 } : {}}
                    onClick={() => module.status !== 'locked' && setSelectedModule(module)}
                  >
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${module.status === 'completed' ? 'bg-green-500' : module.status === 'in_progress' ? 'bg-teal-500' : module.status === 'available' ? 'bg-slate-700' : 'bg-slate-800'}`}>
                      {module.status === 'completed' ? <Check className="h-5 w-5 text-white" /> : module.status === 'locked' ? <Lock className="h-5 w-5 text-slate-500" /> : <Play className="h-5 w-5 text-white" />}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-white">{module.title}</h4>
                      <p className="text-slate-500 text-sm burmese-text">{module.titleMm}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-slate-400 text-sm">{module.duration}</div>
                      <div className="text-amber-400 text-sm">+{module.points} pts</div>
                    </div>
                  </motion.div>
                ))}
              </div>
              
              {getTrackProgress(selectedTrack) === 100 && (
                <div className="flex gap-4">
                  <Button className="flex-1 btn-primary"><Download className="mr-2 h-4 w-4" />Download Certificate</Button>
                  <Button variant="outline" className="flex-1 border-white/10"><Share2 className="mr-2 h-4 w-4" />Share</Button>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Module Detail/Learning Modal */}
      <AnimatePresence>
        {selectedModule && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto"
            onClick={() => setSelectedModule(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-2xl glass-card p-6 bg-slate-900 my-8"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setSelectedModule(null)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white"
              >
                <X className="h-6 w-6" />
              </button>

              {/* Module Header */}
              <div className="flex items-center gap-4 mb-6">
                <div className={`w-14 h-14 rounded-xl bg-gradient-to-r ${selectedTrack?.color} flex items-center justify-center`}>
                  {selectedModule.status === 'completed' ? (
                    <Check className="h-7 w-7 text-white" />
                  ) : (
                    <Play className="h-7 w-7 text-white" />
                  )}
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">{selectedModule.title}</h2>
                  <p className="text-slate-500 text-sm burmese-text">{selectedModule.titleMm}</p>
                </div>
                <Badge className="ml-auto bg-amber-500/20 text-amber-400 border-amber-500/30">
                  +{selectedModule.points} pts
                </Badge>
              </div>

              {/* Module Content */}
              <div className="mb-6">
                <div className="p-4 rounded-xl bg-slate-800/50 mb-4">
                  <h4 className="text-white font-medium mb-2">Lesson Content</h4>
                  <p className="text-slate-400 text-sm leading-relaxed">
                    This module covers essential concepts and practical applications. 
                    Read through the content carefully and take notes. When you're ready, 
                    mark the module as complete to earn your points.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/50 mb-4">
                  <h4 className="text-white font-medium mb-2">Key Takeaways</h4>
                  <ul className="text-slate-400 text-sm space-y-2">
                    <li className="flex items-start gap-2">
                      <Star className="h-4 w-4 text-amber-400 mt-0.5" />
                      Understand the core concepts and their applications
                    </li>
                    <li className="flex items-start gap-2">
                      <Star className="h-4 w-4 text-amber-400 mt-0.5" />
                      Apply what you learn in real-world scenarios
                    </li>
                    <li className="flex items-start gap-2">
                      <Star className="h-4 w-4 text-amber-400 mt-0.5" />
                      Practice with exercises and quizzes
                    </li>
                  </ul>
                </div>

                <div className="flex items-center gap-2 text-sm text-slate-400">
                  <span className="flex items-center gap-1"><BookOpen className="h-4 w-4" />{selectedModule.duration}</span>
                  <span className="text-slate-600">•</span>
                  <span className="flex items-center gap-1"><Target className="h-4 w-4" />Beginner friendly</span>
                </div>
              </div>

              {/* Completion Actions */}
              {selectedModule.status === 'completed' ? (
                <div className="p-4 rounded-xl bg-green-500/10 border border-green-500/20">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center">
                      <Check className="h-5 w-5 text-green-400" />
                    </div>
                    <div>
                      <p className="text-white font-medium">Module Completed!</p>
                      <p className="text-slate-400 text-sm">You've earned {selectedModule.points} points</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    className="flex-1 border-white/10"
                    onClick={() => setSelectedModule(null)}
                  >
                    Continue Later
                  </Button>
                  <Button
                    className="flex-1 btn-primary"
                    onClick={() => handleModuleComplete(selectedModule.id, selectedModule.title, selectedModule.points)}
                  >
                    <Check className="mr-2 h-4 w-4" />
                    Mark Complete
                  </Button>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Celebration Animation */}
      <AnimatePresence>
        {showCelebration && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[70] flex items-center justify-center bg-black/50 backdrop-blur-sm overflow-hidden"
          >
            {/* Confetti */}
            {confetti.map((particle) => (
              <motion.div
                key={particle.id}
                initial={{ 
                  x: `${particle.x}vw`, 
                  y: `-10vh`,
                  rotate: 0,
                  opacity: 1
                }}
                animate={{ 
                  y: `110vh`,
                  rotate: Math.random() * 360,
                  opacity: 0
                }}
                transition={{ 
                  duration: 2 + Math.random() * 2,
                  delay: particle.delay,
                  ease: 'easeIn'
                }}
                className="absolute pointer-events-none"
                style={{
                  width: particle.size,
                  height: particle.size,
                  backgroundColor: particle.color,
                  borderRadius: Math.random() > 0.5 ? '50%' : '0%',
                }}
              />
            ))}

            {/* Main Celebration */}
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.5, opacity: 0 }}
              className="text-center relative z-10"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: [0, 1.3, 1] }}
                transition={{ duration: 0.5 }}
                className="text-8xl mb-4"
              >
                🎉
              </motion.div>
              <motion.h2
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="text-3xl font-bold text-white mb-2"
              >
                Module Completed!
              </motion.h2>
              {completedModuleInfo && (
                <>
                  <motion.p
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.3 }}
                    className="text-slate-300"
                  >
                    {completedModuleInfo.title}
                  </motion.p>
                  <motion.div
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.4 }}
                  >
                    <Badge className="mt-4 bg-amber-500/20 text-amber-400 border-amber-500/30 text-lg py-2 px-4">
                      <Sparkles className="h-5 w-5 mr-2" />
                      +{completedModuleInfo.points} Points!
                    </Badge>
                  </motion.div>
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
