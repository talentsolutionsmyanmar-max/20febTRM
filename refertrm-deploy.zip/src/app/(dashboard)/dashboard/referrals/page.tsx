'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Users, Copy, Share2, ExternalLink, Gift, TrendingUp, Clock, CheckCircle, Link2, Send, Crown, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';

const mockReferrals = [
  { id: '1', name: 'Thiha Aung', email: 'thiha@email.com', status: 'registered', date: '2024-01-10', reward: 25 },
  { id: '2', name: 'Su Myat', email: 'sumyat@email.com', status: 'completed', date: '2024-01-08', reward: 300 },
  { id: '3', name: 'Aung Min', email: 'aungmin@email.com', status: 'registered', date: '2024-01-05', reward: 25 },
];

const sharePlatforms = [
  { name: 'Telegram', icon: Send, color: 'bg-blue-500', url: 'https://t.me/share/url?url=' },
  { name: 'Facebook', icon: Share2, color: 'bg-blue-600', url: 'https://www.facebook.com/sharer/sharer.php?u=' },
  { name: 'Copy Link', icon: Link2, color: 'bg-slate-600', url: '' },
];

export default function ReferralsPage() {
  const { user } = useAuth();
  const [copied, setCopied] = useState(false);

  const referralLink = `https://refertrm.com/ref/${user?.referralCode || 'REFABC12'}`;

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = (platform: typeof sharePlatforms[0]) => {
    if (platform.name === 'Copy Link') {
      copyToClipboard(referralLink);
    } else {
      window.open(platform.url + encodeURIComponent(referralLink), '_blank');
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Referral Program</h1>
          <p className="text-slate-400 burmese-text">ရည်ညွှန်းမှု ပရိုဂရမ်</p>
        </div>
      </div>

      {/* Referral Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card className="glass-card bg-gradient-to-br from-teal-500/10 to-cyan-500/10 border-teal-500/20">
            <CardContent className="p-5 text-center">
              <Users className="h-8 w-8 text-teal-400 mx-auto mb-2" />
              <div className="text-3xl font-bold text-teal-400">{mockReferrals.length}</div>
              <div className="text-sm text-slate-400">Total Referrals</div>
            </CardContent>
          </Card>
        </motion.div>
        
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Card className="glass-card bg-gradient-to-br from-green-500/10 to-emerald-500/10 border-green-500/20">
            <CardContent className="p-5 text-center">
              <CheckCircle className="h-8 w-8 text-green-400 mx-auto mb-2" />
              <div className="text-3xl font-bold text-green-400">{mockReferrals.filter(r => r.status === 'completed').length}</div>
              <div className="text-sm text-slate-400">Successful</div>
            </CardContent>
          </Card>
        </motion.div>
        
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Card className="glass-card bg-gradient-to-br from-amber-500/10 to-orange-500/10 border-amber-500/20">
            <CardContent className="p-5 text-center">
              <Gift className="h-8 w-8 text-amber-400 mx-auto mb-2" />
              <div className="text-3xl font-bold text-amber-400">{mockReferrals.reduce((s, r) => s + r.reward, 0)}</div>
              <div className="text-sm text-slate-400">Points Earned</div>
            </CardContent>
          </Card>
        </motion.div>
        
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <Card className="glass-card bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/20">
            <CardContent className="p-5 text-center">
              <TrendingUp className="h-8 w-8 text-purple-400 mx-auto mb-2" />
              <div className="text-3xl font-bold text-purple-400">+15%</div>
              <div className="text-sm text-slate-400">Bonus Rate</div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Referral Code Card */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
        <Card className="glass-card bg-gradient-to-r from-teal-500/10 to-cyan-500/10 border-teal-500/30">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-4">
                  <Crown className="h-6 w-6 text-amber-400" />
                  <h3 className="text-xl font-bold text-white">Your Unique Referral Code</h3>
                </div>
                <p className="text-slate-400 mb-4">Share this code with friends. You earn +15% permanent bonus on every successful referral!</p>
                
                <div className="flex items-center gap-3 mb-4">
                  <div className="flex-1 relative">
                    <input
                      type="text"
                      value={user?.referralCode || 'REFABC12'}
                      readOnly
                      className="form-input text-center text-xl font-mono tracking-wider"
                    />
                  </div>
                  <Button
                    variant="outline"
                    className="border-white/10 px-4"
                    onClick={() => copyToClipboard(user?.referralCode || 'REFABC12')}
                  >
                    {copied ? <CheckCircle className="h-5 w-5 text-green-400" /> : <Copy className="h-5 w-5" />}
                  </Button>
                </div>
                
                <div className="flex items-center gap-3">
                  <input
                    type="text"
                    value={referralLink}
                    readOnly
                    className="form-input text-sm flex-1"
                  />
                  <Button
                    variant="outline"
                    className="border-white/10 px-4"
                    onClick={() => copyToClipboard(referralLink)}
                  >
                    <Link2 className="h-5 w-5" />
                  </Button>
                </div>
              </div>
              
              <div className="flex flex-col gap-2">
                {sharePlatforms.map((platform) => (
                  <Button
                    key={platform.name}
                    className={`${platform.color} hover:opacity-90 text-white`}
                    onClick={() => handleShare(platform)}
                  >
                    <platform.icon className="mr-2 h-4 w-4" />
                    {platform.name}
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* How It Works */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>
        <Card className="glass-card">
          <CardHeader>
            <h3 className="text-lg font-bold text-white">How Referrals Work</h3>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                { step: 1, title: 'Share Your Code', desc: 'Send your unique code to friends via Telegram, Facebook, or any platform' },
                { step: 2, title: 'They Sign Up', desc: 'Your friend registers using your referral code and gets +50 bonus points' },
                { step: 3, title: 'You Earn', desc: 'Get +25 pts when they register, +15% bonus on every successful hire they make!' },
              ].map((item) => (
                <div key={item.step} className="text-center">
                  <div className="w-12 h-12 rounded-full bg-teal-500 flex items-center justify-center mx-auto mb-3">
                    <span className="text-xl font-bold text-slate-900">{item.step}</span>
                  </div>
                  <h4 className="font-medium text-white mb-2">{item.title}</h4>
                  <p className="text-sm text-slate-400">{item.desc}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Referrals List */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 }}>
        <Card className="glass-card">
          <CardHeader>
            <h3 className="text-lg font-bold text-white">Your Referrals</h3>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {mockReferrals.map((referral) => (
                <div key={referral.id} className="flex items-center gap-4 p-4 rounded-xl bg-slate-800/30">
                  <div className="avatar avatar-lg bg-gradient-to-r from-teal-500 to-cyan-500 text-xl">
                    {referral.name.charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-white">{referral.name}</p>
                    <p className="text-sm text-slate-500">{referral.email}</p>
                  </div>
                  <Badge className={referral.status === 'completed' ? 'badge-success' : 'badge-info'}>
                    {referral.status === 'completed' ? 'Completed' : 'Registered'}
                  </Badge>
                  <div className="text-right">
                    <div className="text-amber-400 font-medium">+{referral.reward} pts</div>
                    <div className="text-xs text-slate-500">{referral.date}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
