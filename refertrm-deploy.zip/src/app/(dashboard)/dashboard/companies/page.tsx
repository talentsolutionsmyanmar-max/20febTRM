'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Building2,
  Star,
  Users,
  MapPin,
  TrendingUp,
  Briefcase,
  X,
  ExternalLink,
  ThumbsUp,
  MessageSquare,
  DollarSign,
  Clock,
  Award,
  Globe,
  ChevronRight,
  PenSquare,
  Check,
  Sparkles,
} from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';

interface Company {
  id: string;
  name: string;
  nameMm?: string;
  logo: string;
  industry: string;
  location: string;
  size: string;
  rating: number;
  reviewCount: number;
  recommendPercent: number;
  salaryMin: number;
  salaryMax: number;
  openJobs: number;
  description: string;
  ratings: {
    workLifeBalance: number;
    compensation: number;
    jobSecurity: number;
    management: number;
    culture: number;
  };
  reviews: CompanyReview[];
  featured?: boolean;
}

interface CompanyReview {
  id: string;
  title: string;
  summary: string;
  cons?: string;
  advice?: string;
  rating: number;
  ratings?: {
    workLifeBalance: number;
    compensation: number;
    jobSecurity: number;
    management: number;
    culture: number;
  };
  jobTitle: string;
  employmentType: 'current' | 'former';
  helpfulCount: number;
  createdAt: string;
}

interface ReviewFormData {
  title: string;
  jobTitle: string;
  employmentType: 'current' | 'former';
  pros: string;
  cons: string;
  advice: string;
  ratings: {
    workLifeBalance: number;
    compensation: number;
    jobSecurity: number;
    management: number;
    culture: number;
  };
}

const companies: Company[] = [
  {
    id: '1',
    name: 'Unicharm Myanmar',
    nameMm: 'ယူနီချမ်မြန်မာ',
    logo: '🏭',
    industry: 'FMCG',
    location: 'Yangon',
    size: '201-500',
    rating: 4.2,
    reviewCount: 28,
    recommendPercent: 85,
    salaryMin: 350000,
    salaryMax: 1700000,
    openJobs: 3,
    description: 'Leading consumer goods company in Myanmar, known for personal care products.',
    ratings: {
      workLifeBalance: 4.0,
      compensation: 4.3,
      jobSecurity: 4.1,
      management: 3.9,
      culture: 4.4,
    },
    reviews: [
      {
        id: '1',
        title: 'Great place to learn and grow',
        summary: 'Supportive team and good benefits. Opportunities for career advancement.',
        cons: 'Sometimes long hours during peak seasons',
        rating: 4.5,
        jobTitle: 'Brand Executive',
        employmentType: 'current',
        helpfulCount: 12,
        createdAt: '2 weeks ago',
      },
      {
        id: '2',
        title: 'Professional environment',
        summary: 'Good training programs and supportive management. Fair compensation.',
        rating: 4.0,
        jobTitle: 'Marketing Assistant',
        employmentType: 'former',
        helpfulCount: 8,
        createdAt: '1 month ago',
      },
    ],
    featured: true,
  },
  {
    id: '2',
    name: 'Wave Plus',
    nameMm: 'ဝေဖ်ပလပ်စ်',
    logo: '📱',
    industry: 'Technology',
    location: 'Yangon',
    size: '51-200',
    rating: 4.5,
    reviewCount: 45,
    recommendPercent: 92,
    salaryMin: 400000,
    salaryMax: 1200000,
    openJobs: 1,
    description: 'Fast-growing fintech company providing mobile financial services across Myanmar.',
    ratings: {
      workLifeBalance: 4.3,
      compensation: 4.6,
      jobSecurity: 4.4,
      management: 4.5,
      culture: 4.7,
    },
    reviews: [
      {
        id: '1',
        title: 'Exciting work environment',
        summary: 'Cutting-edge technology and smart colleagues. Great for tech professionals.',
        cons: 'Fast-paced can mean pressure',
        rating: 5.0,
        jobTitle: 'IT Supervisor',
        employmentType: 'current',
        helpfulCount: 23,
        createdAt: '1 week ago',
      },
    ],
    featured: true,
  },
  {
    id: '3',
    name: 'KBZ Life Insurance',
    nameMm: 'KBZ လူမှုဖူလုံရေး',
    logo: '🏦',
    industry: 'Insurance',
    location: 'Yangon',
    size: '500+',
    rating: 3.9,
    reviewCount: 52,
    recommendPercent: 78,
    salaryMin: 300000,
    salaryMax: 800000,
    openJobs: 1,
    description: 'One of Myanmar\'s largest insurance companies, part of KBZ Group.',
    ratings: {
      workLifeBalance: 3.8,
      compensation: 4.0,
      jobSecurity: 4.2,
      management: 3.7,
      culture: 3.9,
    },
    reviews: [
      {
        id: '1',
        title: 'Stable career option',
        summary: 'Good for those seeking job security and structured career path.',
        cons: 'Bureaucratic processes',
        rating: 4.0,
        jobTitle: 'Accountant',
        employmentType: 'current',
        helpfulCount: 15,
        createdAt: '3 weeks ago',
      },
    ],
  },
  {
    id: '4',
    name: 'Delight Amatat',
    nameMm: 'ဒိလိုက်အမတတ်',
    logo: '🏠',
    industry: 'Construction',
    location: 'Yangon',
    size: '51-200',
    rating: 4.1,
    reviewCount: 18,
    recommendPercent: 83,
    salaryMin: 1000000,
    salaryMax: 1500000,
    openJobs: 2,
    description: 'Premium interior design and construction company in Myanmar.',
    ratings: {
      workLifeBalance: 3.9,
      compensation: 4.4,
      jobSecurity: 4.0,
      management: 4.1,
      culture: 4.2,
    },
    reviews: [],
  },
  {
    id: '5',
    name: 'WOW Sport',
    nameMm: 'WOW အားကစား',
    logo: '⚽',
    industry: 'Retail',
    location: 'Yangon',
    size: '51-200',
    rating: 3.8,
    reviewCount: 22,
    recommendPercent: 75,
    salaryMin: 500000,
    salaryMax: 1000000,
    openJobs: 2,
    description: 'Leading sports retail chain with multiple locations across Myanmar.',
    ratings: {
      workLifeBalance: 4.0,
      compensation: 3.6,
      jobSecurity: 3.8,
      management: 3.7,
      culture: 4.0,
    },
    reviews: [],
  },
  {
    id: '6',
    name: 'GK International Company',
    nameMm: 'GK နိုင်ငံတကာ ကုမ္ပဏီ',
    logo: '🌐',
    industry: 'Trading',
    location: 'Yangon',
    size: '51-200',
    rating: 3.7,
    reviewCount: 15,
    recommendPercent: 72,
    salaryMin: 350000,
    salaryMax: 800000,
    openJobs: 2,
    description: 'International trading company dealing in various consumer products.',
    ratings: {
      workLifeBalance: 3.6,
      compensation: 3.8,
      jobSecurity: 3.7,
      management: 3.6,
      culture: 3.8,
    },
    reviews: [],
  },
];

const industries = ['All', 'FMCG', 'Technology', 'Insurance', 'Construction', 'Retail', 'Trading'];

const jobTitles = [
  'Brand Executive',
  'Marketing Assistant',
  'IT Supervisor',
  'Accountant',
  'Sales Representative',
  'HR Manager',
  'Software Developer',
  'Operations Manager',
  'Customer Service',
  'Finance Analyst',
  'Other',
];

const initialReviewForm: ReviewFormData = {
  title: '',
  jobTitle: '',
  employmentType: 'current',
  pros: '',
  cons: '',
  advice: '',
  ratings: {
    workLifeBalance: 3,
    compensation: 3,
    jobSecurity: 3,
    management: 3,
    culture: 3,
  },
};

const StarRating = ({ rating, size = 'sm' }: { rating: number; size?: 'sm' | 'lg' }) => (
  <div className="flex items-center gap-1">
    {[1, 2, 3, 4, 5].map((star) => (
      <Star
        key={star}
        className={`${size === 'sm' ? 'h-4 w-4' : 'h-5 w-5'} ${
          star <= rating ? 'text-amber-400 fill-amber-400' : 'text-slate-600'
        }`}
      />
    ))}
    <span className="ml-1 text-slate-400 text-sm">{rating.toFixed(1)}</span>
  </div>
);

const RatingSlider = ({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (value: number) => void;
}) => (
  <div className="space-y-2">
    <div className="flex justify-between items-center">
      <span className="text-sm text-slate-400">{label}</span>
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => onChange(star)}
            className="focus:outline-none"
          >
            <Star
              className={`h-5 w-5 transition-colors ${
                star <= value ? 'text-amber-400 fill-amber-400' : 'text-slate-600'
              }`}
            />
          </button>
        ))}
      </div>
    </div>
  </div>
);

export default function CompaniesPage() {
  const { toast } = useToast();
  const [companiesList, setCompaniesList] = useState<Company[]>(companies);
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIndustry, setSelectedIndustry] = useState('All');
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [reviewForm, setReviewForm] = useState<ReviewFormData>(initialReviewForm);
  const [showCelebration, setShowCelebration] = useState(false);

  const filteredCompanies = companiesList.filter((company) => {
    const matchesSearch = company.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      company.industry.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesIndustry = selectedIndustry === 'All' || company.industry === selectedIndustry;
    return matchesSearch && matchesIndustry;
  });

  const featuredCompanies = companiesList.filter(c => c.featured);

  const handleOpenReviewModal = () => {
    setReviewForm(initialReviewForm);
    setShowReviewModal(true);
  };

  const handleSubmitReview = () => {
    if (!selectedCompany || !reviewForm.title || !reviewForm.jobTitle || !reviewForm.pros) {
      toast({
        title: 'Missing fields',
        description: 'Please fill in all required fields.',
        variant: 'destructive',
      });
      return;
    }

    const overallRating = Math.round(
      (reviewForm.ratings.workLifeBalance +
        reviewForm.ratings.compensation +
        reviewForm.ratings.jobSecurity +
        reviewForm.ratings.management +
        reviewForm.ratings.culture) / 5
    );

    const newReview: CompanyReview = {
      id: `review_${Date.now()}`,
      title: reviewForm.title,
      summary: reviewForm.pros,
      cons: reviewForm.cons || undefined,
      advice: reviewForm.advice || undefined,
      rating: overallRating,
      ratings: reviewForm.ratings,
      jobTitle: reviewForm.jobTitle,
      employmentType: reviewForm.employmentType,
      helpfulCount: 0,
      createdAt: 'Just now',
    };

    setCompaniesList(prev =>
      prev.map(c =>
        c.id === selectedCompany.id
          ? {
              ...c,
              reviews: [newReview, ...c.reviews],
              reviewCount: c.reviewCount + 1,
              rating: Math.round(((c.rating * c.reviewCount) + overallRating) / (c.reviewCount + 1) * 10) / 10,
            }
          : c
      )
    );

    // Update selected company to reflect the new review
    setSelectedCompany(prev =>
      prev
        ? {
            ...prev,
            reviews: [newReview, ...prev.reviews],
            reviewCount: prev.reviewCount + 1,
            rating: Math.round(((prev.rating * prev.reviewCount) + overallRating) / (prev.reviewCount + 1) * 10) / 10,
          }
        : null
    );

    setShowReviewModal(false);
    setShowCelebration(true);
    setTimeout(() => setShowCelebration(false), 2000);

    toast({
      title: 'Review submitted!',
      description: 'Thank you for sharing your experience. +10 points earned!',
    });
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Building2 className="h-7 w-7 text-teal-400" />
            Company Profiles
          </h1>
          <p className="text-slate-400 burmese-text">ကုမ္ပဏီ ပရိုဖိုင်များ - အလုပ်ရှင်များကို သုံးသပ်ပါ</p>
        </div>
        <div className="flex items-center gap-3">
          <Badge className="bg-teal-500/20 text-teal-400 border-teal-500/30 text-sm">
            <Building2 className="h-4 w-4 mr-1" />
            {companies.length} Companies
          </Badge>
          <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-sm">
            <Briefcase className="h-4 w-4 mr-1" />
            {companies.reduce((sum, c) => sum + c.openJobs, 0)} Open Jobs
          </Badge>
        </div>
      </div>

      {/* Featured Companies */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          <Award className="h-5 w-5 text-amber-400" />
          Featured Companies
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {featuredCompanies.map((company, index) => (
            <motion.div
              key={company.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card 
                className="glass-card-hover cursor-pointer border-amber-500/20 bg-gradient-to-r from-amber-500/5 to-orange-500/5"
                onClick={() => setSelectedCompany(company)}
              >
                <CardContent className="p-5">
                  <div className="flex items-start gap-4">
                    <div className="text-4xl">{company.logo}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="text-lg font-bold text-white">{company.name}</h3>
                        <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30 text-xs">
                          Featured
                        </Badge>
                      </div>
                      <p className="text-slate-500 text-sm burmese-text">{company.nameMm}</p>
                      <div className="flex items-center gap-3 mt-2">
                        <StarRating rating={company.rating} />
                        <span className="text-slate-400 text-sm">({company.reviewCount} reviews)</span>
                      </div>
                      <div className="flex flex-wrap items-center gap-2 mt-3 text-sm">
                        <Badge variant="outline" className="border-white/10 text-slate-300">
                          {company.industry}
                        </Badge>
                        <Badge variant="outline" className="border-white/10 text-slate-300">
                          <MapPin className="h-3 w-3 mr-1" />
                          {company.location}
                        </Badge>
                        <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                          {company.openJobs} jobs
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Search & Filters */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card p-4"
      >
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search companies..."
              className="form-input w-full pl-4"
            />
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {industries.map((industry) => (
              <button
                key={industry}
                onClick={() => setSelectedIndustry(industry)}
                className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
                  selectedIndustry === industry
                    ? 'bg-teal-500 text-slate-900'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {industry}
              </button>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Company List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredCompanies.map((company, index) => (
          <motion.div
            key={company.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
          >
            <Card 
              className="glass-card-hover cursor-pointer h-full"
              onClick={() => setSelectedCompany(company)}
            >
              <CardContent className="p-5">
                <div className="flex items-start gap-4 mb-4">
                  <div className="text-3xl">{company.logo}</div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-lg font-bold text-white truncate">{company.name}</h3>
                    <p className="text-slate-500 text-sm">{company.industry}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 mb-3">
                  <StarRating rating={company.rating} />
                  <span className="text-slate-500 text-sm">({company.reviewCount})</span>
                </div>

                <div className="flex items-center gap-2 text-sm text-slate-400 mb-3">
                  <MapPin className="h-4 w-4" />
                  <span>{company.location}</span>
                  <span className="text-slate-600">•</span>
                  <span>{company.size}</span>
                </div>

                <div className="flex items-center justify-between">
                  <div className="text-sm">
                    <span className="text-slate-500">Salary: </span>
                    <span className="text-green-400 font-medium">
                      {(company.salaryMin / 100000).toFixed(1)}-{(company.salaryMax / 100000).toFixed(1)}L
                    </span>
                  </div>
                  <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                    {company.openJobs} jobs
                  </Badge>
                </div>

                <div className="mt-3 pt-3 border-t border-white/5">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-500">Recommend</span>
                    <span className="text-teal-400 font-medium">{company.recommendPercent}%</span>
                  </div>
                  <Progress value={company.recommendPercent} className="h-1.5 mt-1 bg-slate-700" />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Company Detail Modal */}
      <AnimatePresence>
        {selectedCompany && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto"
            onClick={() => setSelectedCompany(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-3xl glass-card bg-slate-900 my-8"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header */}
              <div className="p-6 border-b border-white/5">
                <button
                  onClick={() => setSelectedCompany(null)}
                  className="absolute top-4 right-4 text-slate-400 hover:text-white"
                >
                  <X className="h-6 w-6" />
                </button>

                <div className="flex items-start gap-4">
                  <div className="text-5xl">{selectedCompany.logo}</div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h2 className="text-2xl font-bold text-white">{selectedCompany.name}</h2>
                      {selectedCompany.featured && (
                        <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                          Featured
                        </Badge>
                      )}
                    </div>
                    <p className="text-slate-500 burmese-text">{selectedCompany.nameMm}</p>
                    <div className="flex items-center gap-4 mt-3">
                      <StarRating rating={selectedCompany.rating} size="lg" />
                      <span className="text-slate-400">({selectedCompany.reviewCount} reviews)</span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-3 mt-4">
                  <Badge variant="outline" className="border-white/10 text-slate-300">
                    {selectedCompany.industry}
                  </Badge>
                  <Badge variant="outline" className="border-white/10 text-slate-300">
                    <MapPin className="h-3 w-3 mr-1" />
                    {selectedCompany.location}
                  </Badge>
                  <Badge variant="outline" className="border-white/10 text-slate-300">
                    <Users className="h-3 w-3 mr-1" />
                    {selectedCompany.size} employees
                  </Badge>
                  <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                    {selectedCompany.openJobs} open jobs
                  </Badge>
                </div>
              </div>

              {/* Content */}
              <div className="p-6 space-y-6">
                {/* Description */}
                <div>
                  <h3 className="text-lg font-bold text-white mb-2">About</h3>
                  <p className="text-slate-400">{selectedCompany.description}</p>
                </div>

                {/* Ratings Breakdown */}
                <div>
                  <h3 className="text-lg font-bold text-white mb-4">Ratings Breakdown</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {Object.entries(selectedCompany.ratings).map(([key, value]) => (
                      <div key={key} className="p-3 rounded-xl bg-slate-800/50">
                        <div className="text-slate-400 text-sm capitalize mb-1">
                          {key.replace(/([A-Z])/g, ' $1').trim()}
                        </div>
                        <div className="flex items-center gap-2">
                          <Progress value={value * 20} className="h-2 flex-1 bg-slate-700" />
                          <span className="text-white font-medium">{value.toFixed(1)}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Salary Insights */}
                <div className="p-4 rounded-xl bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-green-500/20">
                  <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-green-400" />
                    Salary Range
                  </h3>
                  <div className="text-2xl font-bold text-green-400">
                    {(selectedCompany.salaryMin / 100000).toFixed(1)} - {(selectedCompany.salaryMax / 100000).toFixed(1)} Lakhs MMK
                  </div>
                  <p className="text-slate-500 text-sm mt-1">
                    Based on {selectedCompany.reviewCount} employee reports
                  </p>
                </div>

                {/* Reviews */}
                {selectedCompany.reviews.length > 0 && (
                  <div>
                    <h3 className="text-lg font-bold text-white mb-4">Recent Reviews</h3>
                    <div className="space-y-4">
                      {selectedCompany.reviews.map((review) => (
                        <div key={review.id} className="p-4 rounded-xl bg-slate-800/50">
                          <div className="flex items-start justify-between mb-2">
                            <h4 className="text-white font-medium">{review.title}</h4>
                            <StarRating rating={review.rating} />
                          </div>
                          <p className="text-slate-400 text-sm mb-2">{review.summary}</p>
                          {review.cons && (
                            <p className="text-slate-500 text-sm"><strong>Cons:</strong> {review.cons}</p>
                          )}
                          <div className="flex items-center justify-between mt-3 pt-3 border-t border-white/5">
                            <div className="flex items-center gap-2 text-slate-500 text-sm">
                              <span>{review.jobTitle}</span>
                              <span className="text-slate-600">•</span>
                              <span className={review.employmentType === 'current' ? 'text-green-400' : 'text-slate-400'}>
                                {review.employmentType === 'current' ? 'Current Employee' : 'Former Employee'}
                              </span>
                            </div>
                            <button className="flex items-center gap-1 text-slate-400 text-sm hover:text-teal-400">
                              <ThumbsUp className="h-4 w-4" />
                              {review.helpfulCount}
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Write Review CTA */}
                <div className="flex gap-3">
                  <Button className="flex-1 btn-primary" onClick={handleOpenReviewModal}>
                    <PenSquare className="mr-2 h-4 w-4" />
                    Write a Review
                  </Button>
                  <Button variant="outline" className="border-white/10">
                    <ExternalLink className="mr-2 h-4 w-4" />
                    View Jobs
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Review Writing Modal */}
      <AnimatePresence>
        {showReviewModal && selectedCompany && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto"
            onClick={() => setShowReviewModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-2xl glass-card bg-slate-900 my-8 max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="sticky top-0 bg-slate-900/95 backdrop-blur-sm p-6 border-b border-white/5 z-10">
                <button
                  onClick={() => setShowReviewModal(false)}
                  className="absolute top-4 right-4 text-slate-400 hover:text-white"
                >
                  <X className="h-6 w-6" />
                </button>

                <div className="flex items-center gap-4">
                  <div className="text-4xl">{selectedCompany.logo}</div>
                  <div>
                    <h2 className="text-xl font-bold text-white">Write a Review</h2>
                    <p className="text-slate-400">Sharing your experience at {selectedCompany.name}</p>
                  </div>
                </div>
              </div>

              <div className="p-6 space-y-6">
                {/* Job Info */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-slate-400 mb-2">Job Title *</label>
                    <select
                      value={reviewForm.jobTitle}
                      onChange={(e) => setReviewForm({ ...reviewForm, jobTitle: e.target.value })}
                      className="w-full px-4 py-3 bg-slate-800 border border-white/10 rounded-xl text-white focus:border-teal-500 focus:outline-none"
                    >
                      <option value="">Select your position</option>
                      {jobTitles.map((title) => (
                        <option key={title} value={title}>
                          {title}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm text-slate-400 mb-2">Employment Status *</label>
                    <div className="flex gap-3">
                      <button
                        type="button"
                        onClick={() => setReviewForm({ ...reviewForm, employmentType: 'current' })}
                        className={`flex-1 py-3 px-4 rounded-xl text-sm font-medium transition-all ${
                          reviewForm.employmentType === 'current'
                            ? 'bg-green-500 text-white'
                            : 'bg-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        Current Employee
                      </button>
                      <button
                        type="button"
                        onClick={() => setReviewForm({ ...reviewForm, employmentType: 'former' })}
                        className={`flex-1 py-3 px-4 rounded-xl text-sm font-medium transition-all ${
                          reviewForm.employmentType === 'former'
                            ? 'bg-teal-500 text-white'
                            : 'bg-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        Former Employee
                      </button>
                    </div>
                  </div>
                </div>

                {/* Review Title */}
                <div>
                  <label className="block text-sm text-slate-400 mb-2">Review Title *</label>
                  <input
                    type="text"
                    value={reviewForm.title}
                    onChange={(e) => setReviewForm({ ...reviewForm, title: e.target.value })}
                    placeholder="Sum up your experience in one sentence"
                    className="w-full px-4 py-3 bg-slate-800 border border-white/10 rounded-xl text-white placeholder:text-slate-500 focus:border-teal-500 focus:outline-none"
                  />
                </div>

                {/* Category Ratings */}
                <div className="space-y-4">
                  <label className="block text-sm text-slate-400">Ratings</label>
                  <div className="p-4 bg-slate-800/50 rounded-xl space-y-4">
                    <RatingSlider
                      label="Work-Life Balance"
                      value={reviewForm.ratings.workLifeBalance}
                      onChange={(v) =>
                        setReviewForm({
                          ...reviewForm,
                          ratings: { ...reviewForm.ratings, workLifeBalance: v },
                        })
                      }
                    />
                    <RatingSlider
                      label="Compensation & Benefits"
                      value={reviewForm.ratings.compensation}
                      onChange={(v) =>
                        setReviewForm({
                          ...reviewForm,
                          ratings: { ...reviewForm.ratings, compensation: v },
                        })
                      }
                    />
                    <RatingSlider
                      label="Job Security"
                      value={reviewForm.ratings.jobSecurity}
                      onChange={(v) =>
                        setReviewForm({
                          ...reviewForm,
                          ratings: { ...reviewForm.ratings, jobSecurity: v },
                        })
                      }
                    />
                    <RatingSlider
                      label="Management"
                      value={reviewForm.ratings.management}
                      onChange={(v) =>
                        setReviewForm({
                          ...reviewForm,
                          ratings: { ...reviewForm.ratings, management: v },
                        })
                      }
                    />
                    <RatingSlider
                      label="Company Culture"
                      value={reviewForm.ratings.culture}
                      onChange={(v) =>
                        setReviewForm({
                          ...reviewForm,
                          ratings: { ...reviewForm.ratings, culture: v },
                        })
                      }
                    />
                  </div>
                </div>

                {/* Pros */}
                <div>
                  <label className="block text-sm text-slate-400 mb-2">Pros (What did you like?) *</label>
                  <textarea
                    value={reviewForm.pros}
                    onChange={(e) => setReviewForm({ ...reviewForm, pros: e.target.value })}
                    placeholder="Share the positive aspects of working here..."
                    rows={3}
                    className="w-full px-4 py-3 bg-slate-800 border border-white/10 rounded-xl text-white placeholder:text-slate-500 focus:border-teal-500 focus:outline-none resize-none"
                  />
                </div>

                {/* Cons */}
                <div>
                  <label className="block text-sm text-slate-400 mb-2">Cons (What could be improved?)</label>
                  <textarea
                    value={reviewForm.cons}
                    onChange={(e) => setReviewForm({ ...reviewForm, cons: e.target.value })}
                    placeholder="Share areas for improvement..."
                    rows={3}
                    className="w-full px-4 py-3 bg-slate-800 border border-white/10 rounded-xl text-white placeholder:text-slate-500 focus:border-teal-500 focus:outline-none resize-none"
                  />
                </div>

                {/* Advice to Management */}
                <div>
                  <label className="block text-sm text-slate-400 mb-2">Advice to Management</label>
                  <textarea
                    value={reviewForm.advice}
                    onChange={(e) => setReviewForm({ ...reviewForm, advice: e.target.value })}
                    placeholder="What suggestions do you have for leadership?"
                    rows={2}
                    className="w-full px-4 py-3 bg-slate-800 border border-white/10 rounded-xl text-white placeholder:text-slate-500 focus:border-teal-500 focus:outline-none resize-none"
                  />
                </div>

                {/* Submit Buttons */}
                <div className="flex gap-3 pt-4">
                  <Button
                    variant="outline"
                    className="flex-1 border-white/10"
                    onClick={() => setShowReviewModal(false)}
                  >
                    Cancel
                  </Button>
                  <Button className="flex-1 btn-primary" onClick={handleSubmitReview}>
                    <PenSquare className="mr-2 h-4 w-4" />
                    Submit Review
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Celebration Overlay */}
      <AnimatePresence>
        {showCelebration && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[70] flex items-center justify-center bg-black/50 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.5, opacity: 0 }}
              className="text-center"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: [0, 1.2, 1] }}
                transition={{ duration: 0.5 }}
                className="text-8xl mb-4"
              >
                🎉
              </motion.div>
              <h2 className="text-2xl font-bold text-white mb-2">Thank You!</h2>
              <p className="text-slate-400">Your review has been submitted</p>
              <Badge className="mt-4 bg-amber-500/20 text-amber-400 border-amber-500/30">
                <Sparkles className="h-4 w-4 mr-1" />
                +10 Points Earned!
              </Badge>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
