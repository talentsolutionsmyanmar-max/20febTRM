'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { User, Bell, Shield, Palette, Globe, Save, Eye, Wifi, Check, Crown, Star, Sparkles, Lock, Zap, Award, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';

interface AvatarOption {
  id: string;
  name: string;
  nameMm: string;
  image: string;
  category: 'starter' | 'professional' | 'champion' | 'legendary';
  cost: number;
  description: string;
  descriptionMm: string;
}

const avatarCollection: AvatarOption[] = [
  // Starter Avatars (Free)
  {
    id: 'student',
    name: 'Eager Learner',
    nameMm: 'သင်ယူလိုစိတ်',
    image: '/avatars/avatar-student.png',
    category: 'starter',
    cost: 0,
    description: 'Ready to learn and grow',
    descriptionMm: 'သင်ယူဖွံ့ဖြိုးရန် အဆင်သင့်',
  },
  {
    id: 'business-1',
    name: 'Business Starter',
    nameMm: 'စီးပွားရေး စတာ',
    image: '/avatars/avatar-business-1.png',
    category: 'starter',
    cost: 0,
    description: 'Professional and ready',
    descriptionMm: 'ပရော်ဖက်ရှင်နယ်',
  },
  
  // Professional Avatars (Unlock with points)
  {
    id: 'tech-1',
    name: 'Tech Wizard',
    nameMm: 'နည်းပညာ မှော်သည်',
    image: '/avatars/avatar-tech-1.png',
    category: 'professional',
    cost: 100,
    description: 'Master of digital skills',
    descriptionMm: 'ဒစ်ဂျစ်တယ် ကျွမ်းကျင်သူ',
  },
  {
    id: 'female-pro-1',
    name: 'Career Queen',
    nameMm: 'အလုပ်အကိုင် ဘုရင်မ',
    image: '/avatars/avatar-female-pro-1.png',
    category: 'professional',
    cost: 100,
    description: 'Leading with confidence',
    descriptionMm: 'ယုံကြည်မှုဖြင့် ဦးဆောင်',
  },
  {
    id: 'creative-1',
    name: 'Creative Mind',
    nameMm: 'ဖန်တီးစိတ်',
    image: '/avatars/avatar-creative-1.png',
    category: 'professional',
    cost: 150,
    description: 'Artistic and innovative',
    descriptionMm: 'အနုပညာနှင့် ဆန်းသစ်',
  },
  {
    id: 'recruiter',
    name: 'Super Recruiter',
    nameMm: 'ဆူပါ ရည်ညွှန်းသူ',
    image: '/avatars/avatar-recruiter.png',
    category: 'professional',
    cost: 200,
    description: 'Connecting talent with opportunities',
    descriptionMm: 'အရည်အချင်းကို အခွင့်အလမ်းနှင့် ချိတ်ဆက်',
  },
  
  // Champion Avatars (Premium)
  {
    id: 'champion',
    name: 'Referral Champion',
    nameMm: 'ရည်ညွှန်း ချန်ပီယံ',
    image: '/avatars/avatar-champion.png',
    category: 'champion',
    cost: 500,
    description: 'Top performer with golden touch',
    descriptionMm: 'ရွှေလက်ရှိ ထိပ်တန်း ဆောင်ရွက်သူ',
  },
  
  // Legendary Avatars (Exclusive)
  {
    id: 'legendary',
    name: 'Master Legend',
    nameMm: 'မာစတာ ဒဏ္ဍာရီ',
    image: '/avatars/avatar-legendary.png',
    category: 'legendary',
    cost: 1000,
    description: 'The ultimate referral master',
    descriptionMm: 'အဆုံးစွန် ရည်ညွှန်း မာစတာ',
  },
];

const categoryInfo = {
  starter: { label: 'Starter', labelMm: 'စတင်သူ', color: 'from-slate-500 to-slate-600', bgColor: 'bg-slate-500/20', borderColor: 'border-slate-500/30', textColor: 'text-slate-300' },
  professional: { label: 'Professional', labelMm: 'ပရော်ဖက်ရှင်နယ်', color: 'from-teal-500 to-cyan-500', bgColor: 'bg-teal-500/20', borderColor: 'border-teal-500/30', textColor: 'text-teal-400' },
  champion: { label: 'Champion', labelMm: 'ချန်ပီယံ', color: 'from-amber-500 to-orange-500', bgColor: 'bg-amber-500/20', borderColor: 'border-amber-500/30', textColor: 'text-amber-400' },
  legendary: { label: 'Legendary', labelMm: 'ဒဏ္ဍာရီ', color: 'from-purple-500 to-pink-500', bgColor: 'bg-purple-500/20', borderColor: 'border-purple-500/30', textColor: 'text-purple-400' },
};

export default function SettingsPage() {
  const { user, deductPoints, addPoints } = useAuth();
  const { toast } = useToast();
  const [textMode, setTextMode] = useState(false);
  const [lowData, setLowData] = useState(false);
  const [notifications, setNotifications] = useState(true);
  const [selectedAvatar, setSelectedAvatar] = useState<string>(user?.avatar?.includes('/') ? user.avatar : '/avatars/avatar-business-1.png');
  const [ownedAvatars, setOwnedAvatars] = useState<string[]>(['student', 'business-1']);
  const [activeCategory, setActiveCategory] = useState<'all' | 'starter' | 'professional' | 'champion' | 'legendary'>('all');
  const [previewAvatar, setPreviewAvatar] = useState<AvatarOption | null>(null);

  const handleSelectAvatar = (avatar: AvatarOption) => {
    if (ownedAvatars.includes(avatar.id)) {
      setSelectedAvatar(avatar.image);
      toast({
        title: 'Avatar equipped! ✨',
        description: `Now wearing: ${avatar.name}`,
      });
    } else if (avatar.cost <= (user?.points || 0)) {
      // Unlock the avatar
      const success = deductPoints(avatar.cost, `Unlocked avatar: ${avatar.name}`);
      if (success) {
        setOwnedAvatars(prev => [...prev, avatar.id]);
        setSelectedAvatar(avatar.image);
        toast({
          title: 'Avatar unlocked! 🎉',
          description: `${avatar.name} is now yours! -${avatar.cost} points`,
        });
      }
    } else {
      toast({
        title: 'Not enough points',
        description: `You need ${avatar.cost - (user?.points || 0)} more points to unlock this avatar.`,
        variant: 'destructive',
      });
    }
  };

  const filteredAvatars = activeCategory === 'all' 
    ? avatarCollection 
    : avatarCollection.filter(a => a.category === activeCategory);

  const currentAvatarInfo = avatarCollection.find(a => a.image === selectedAvatar);

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Settings</h1>
          <p className="text-slate-400 burmese-text">ဆက်တင်များ</p>
        </div>
        <div className="flex items-center gap-3">
          <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
            <Star className="h-4 w-4 mr-1" />{user?.points || 0} pts
          </Badge>
          <Badge className="bg-teal-500/20 text-teal-400 border-teal-500/30">
            <Crown className="h-4 w-4 mr-1" />{user?.level || 'Amateur'}
          </Badge>
        </div>
      </div>

      {/* Avatar Customization Section */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <Card className="glass-card overflow-hidden">
          <div className="p-6 border-b border-white/5 bg-gradient-to-r from-purple-500/5 to-pink-500/5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center">
                  <Crown className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Avatar Collection</h3>
                  <p className="text-slate-500 text-sm burmese-text">Avatar စုစည်းမှု</p>
                </div>
              </div>
              <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                {ownedAvatars.length}/{avatarCollection.length} Owned
              </Badge>
            </div>
          </div>

          <CardContent className="p-6">
            {/* Current Avatar Display */}
            <div className="flex flex-col md:flex-row gap-6 mb-8">
              {/* Avatar Preview */}
              <div className="flex-shrink-0">
                <motion.div 
                  className="relative"
                  whileHover={{ scale: 1.02 }}
                >
                  <div className={`w-40 h-40 rounded-2xl overflow-hidden border-4 ${
                    currentAvatarInfo ? categoryInfo[currentAvatarInfo.category].borderColor : 'border-white/10'
                  } bg-gradient-to-br from-slate-800 to-slate-900 shadow-2xl`}>
                    <Image
                      src={selectedAvatar}
                      alt="Your avatar"
                      width={160}
                      height={160}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  {currentAvatarInfo && (
                    <div className={`absolute -bottom-2 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full ${categoryInfo[currentAvatarInfo.category].bgColor} border ${categoryInfo[currentAvatarInfo.category].borderColor}`}>
                      <span className={`text-sm font-medium ${categoryInfo[currentAvatarInfo.category].textColor}`}>
                        {currentAvatarInfo.name}
                      </span>
                    </div>
                  )}
                </motion.div>
              </div>

              {/* Stats & Info */}
              <div className="flex-1 space-y-4">
                <div>
                  <h4 className="text-white font-bold text-lg">{currentAvatarInfo?.name || 'Select Avatar'}</h4>
                  <p className="text-slate-400 text-sm burmese-text">{currentAvatarInfo?.nameMm || 'Avatar ရွေးပါ'}</p>
                  <p className="text-slate-500 text-sm mt-1">{currentAvatarInfo?.description}</p>
                </div>

                {/* Collection Progress */}
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-400">Collection Progress</span>
                    <span className="text-teal-400">{ownedAvatars.length}/{avatarCollection.length}</span>
                  </div>
                  <Progress value={(ownedAvatars.length / avatarCollection.length) * 100} className="h-2 bg-slate-700" />
                </div>

                {/* Quick Stats */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="p-3 rounded-xl bg-slate-800/50 text-center">
                    <div className="text-2xl font-bold text-teal-400">{ownedAvatars.filter(id => avatarCollection.find(a => a.id === id)?.category === 'starter').length}</div>
                    <div className="text-xs text-slate-500">Starter</div>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-800/50 text-center">
                    <div className="text-2xl font-bold text-amber-400">{ownedAvatars.filter(id => avatarCollection.find(a => a.id === id)?.category === 'champion' || avatarCollection.find(a => a.id === id)?.category === 'legendary').length}</div>
                    <div className="text-xs text-slate-500">Premium</div>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-800/50 text-center">
                    <div className="text-2xl font-bold text-purple-400">{ownedAvatars.filter(id => avatarCollection.find(a => a.id === id)?.category === 'legendary').length}</div>
                    <div className="text-xs text-slate-500">Legendary</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Category Filter */}
            <div className="flex gap-2 overflow-x-auto pb-4 mb-4">
              <button
                onClick={() => setActiveCategory('all')}
                className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
                  activeCategory === 'all' ? 'bg-white/10 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                All ({avatarCollection.length})
              </button>
              {(['starter', 'professional', 'champion', 'legendary'] as const).map((cat) => {
                const count = avatarCollection.filter(a => a.category === cat).length;
                return (
                  <button
                    key={cat}
                    onClick={() => setActiveCategory(cat)}
                    className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all flex items-center gap-2 ${
                      activeCategory === cat 
                        ? `${categoryInfo[cat].bgColor} ${categoryInfo[cat].textColor} border ${categoryInfo[cat].borderColor}` 
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {cat === 'legendary' && <Sparkles className="h-4 w-4" />}
                    {cat === 'champion' && <Award className="h-4 w-4" />}
                    {cat === 'professional' && <Zap className="h-4 w-4" />}
                    {cat === 'starter' && <Star className="h-4 w-4" />}
                    {categoryInfo[cat].label} ({count})
                  </button>
                );
              })}
            </div>

            {/* Avatar Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {filteredAvatars.map((avatar, index) => {
                const owned = ownedAvatars.includes(avatar.id);
                const equipped = selectedAvatar === avatar.image;
                const canAfford = (user?.points || 0) >= avatar.cost;
                const info = categoryInfo[avatar.category];

                return (
                  <motion.div
                    key={avatar.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.03 }}
                    whileHover={{ scale: 1.03, y: -5 }}
                    onClick={() => handleSelectAvatar(avatar)}
                    className={`relative cursor-pointer group`}
                  >
                    <div className={`relative rounded-xl overflow-hidden border-2 transition-all ${
                      equipped 
                        ? `border-teal-500 shadow-lg shadow-teal-500/20` 
                        : owned 
                          ? `${info.borderColor} hover:border-teal-500/50`
                          : canAfford 
                            ? 'border-white/10 hover:border-white/30'
                            : 'border-white/5 opacity-60'
                    }`}>
                      {/* Avatar Image */}
                      <div className="aspect-square bg-gradient-to-br from-slate-800 to-slate-900 relative">
                        <Image
                          src={avatar.image}
                          alt={avatar.name}
                          fill
                          className="object-cover"
                        />
                        
                        {/* Lock Overlay */}
                        {!owned && (
                          <div className="absolute inset-0 bg-slate-900/70 flex flex-col items-center justify-center">
                            <Lock className="h-6 w-6 text-slate-400 mb-1" />
                            <span className="text-amber-400 font-bold text-sm">{avatar.cost} pts</span>
                          </div>
                        )}

                        {/* Equipped Badge */}
                        {equipped && (
                          <div className="absolute top-2 right-2 bg-teal-500 rounded-full p-1">
                            <Check className="h-4 w-4 text-white" />
                          </div>
                        )}

                        {/* Category Badge */}
                        <div className={`absolute top-2 left-2 px-2 py-0.5 rounded-full ${info.bgColor} border ${info.borderColor}`}>
                          <span className={`text-xs font-medium ${info.textColor}`}>{info.label}</span>
                        </div>
                      </div>

                      {/* Info */}
                      <div className="p-3 bg-slate-800/50">
                        <p className="text-white text-sm font-medium truncate">{avatar.name}</p>
                        <p className="text-slate-500 text-xs burmese-text truncate">{avatar.nameMm}</p>
                      </div>
                    </div>

                    {/* Hover Glow Effect */}
                    <div className={`absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity -z-10 blur-xl ${
                      avatar.category === 'legendary' ? 'bg-purple-500/20' :
                      avatar.category === 'champion' ? 'bg-amber-500/20' :
                      'bg-teal-500/10'
                    }`} />
                  </motion.div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Profile Section */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
        <Card className="glass-card">
          <CardHeader>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <User className="h-5 w-5 text-teal-400" />
              Profile
            </h3>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-xl overflow-hidden border-2 border-teal-500/50">
                <Image
                  src={selectedAvatar}
                  alt="Your avatar"
                  width={64}
                  height={64}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1">
                <p className="text-lg font-medium text-white">{user?.displayName || 'Guest User'}</p>
                <p className="text-slate-400">{user?.email || 'Not logged in'}</p>
                <div className="flex items-center gap-2 mt-2">
                  <Badge className="bg-teal-500/20 text-teal-400 border-teal-500/30">{user?.level || 'Amateur'}</Badge>
                  <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                    <Star className="h-3 w-3 mr-1" />{user?.points || 0} pts
                  </Badge>
                </div>
              </div>
            </div>

            {/* Display Name */}
            <div className="mt-4">
              <label className="block text-sm text-slate-400 mb-2">Display Name</label>
              <input
                type="text"
                defaultValue={user?.displayName || ''}
                placeholder="Enter your name"
                className="form-input"
              />
            </div>

            {/* Referral Code */}
            <div className="mt-4 p-4 rounded-xl bg-gradient-to-r from-teal-500/10 to-cyan-500/10 border border-teal-500/20">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400">Your Referral Code</p>
                  <p className="text-xl font-mono text-teal-400 font-bold">{user?.referralCode || 'REFXXXXX'}</p>
                </div>
                <Button
                  variant="outline"
                  className="border-white/10"
                  onClick={() => {
                    navigator.clipboard.writeText(user?.referralCode || '');
                    toast({ title: 'Copied!', description: 'Referral code copied to clipboard' });
                  }}
                >
                  Copy
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Preferences */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
        <Card className="glass-card">
          <CardHeader>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Palette className="h-5 w-5 text-teal-400" />
              Preferences
            </h3>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Text Mode */}
            <div className="flex items-center justify-between p-4 rounded-xl bg-slate-800/30">
              <div className="flex items-center gap-3">
                <Eye className="h-5 w-5 text-slate-400" />
                <div>
                  <p className="font-medium text-white">Text Mode</p>
                  <p className="text-sm text-slate-500">Reduce visual effects for faster loading</p>
                </div>
              </div>
              <button
                onClick={() => setTextMode(!textMode)}
                className={`w-12 h-6 rounded-full transition-colors ${textMode ? 'bg-teal-500' : 'bg-slate-700'}`}
              >
                <div className={`w-5 h-5 rounded-full bg-white transition-transform ${textMode ? 'translate-x-6' : 'translate-x-0.5'}`} />
              </button>
            </div>

            {/* Low Data Mode */}
            <div className="flex items-center justify-between p-4 rounded-xl bg-slate-800/30">
              <div className="flex items-center gap-3">
                <Wifi className="h-5 w-5 text-slate-400" />
                <div>
                  <p className="font-medium text-white">Low Data Mode</p>
                  <p className="text-sm text-slate-500">Reduce data usage for slower connections</p>
                  <p className="text-xs text-slate-600 burmese-text">ဒေတာသက်သာစေရန်</p>
                </div>
              </div>
              <button
                onClick={() => setLowData(!lowData)}
                className={`w-12 h-6 rounded-full transition-colors ${lowData ? 'bg-teal-500' : 'bg-slate-700'}`}
              >
                <div className={`w-5 h-5 rounded-full bg-white transition-transform ${lowData ? 'translate-x-6' : 'translate-x-0.5'}`} />
              </button>
            </div>

            {/* Notifications */}
            <div className="flex items-center justify-between p-4 rounded-xl bg-slate-800/30">
              <div className="flex items-center gap-3">
                <Bell className="h-5 w-5 text-slate-400" />
                <div>
                  <p className="font-medium text-white">Push Notifications</p>
                  <p className="text-sm text-slate-500">Get notified about new jobs and rewards</p>
                </div>
              </div>
              <button
                onClick={() => setNotifications(!notifications)}
                className={`w-12 h-6 rounded-full transition-colors ${notifications ? 'bg-teal-500' : 'bg-slate-700'}`}
              >
                <div className={`w-5 h-5 rounded-full bg-white transition-transform ${notifications ? 'translate-x-6' : 'translate-x-0.5'}`} />
              </button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Language */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
        <Card className="glass-card">
          <CardHeader>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Globe className="h-5 w-5 text-teal-400" />
              Language
            </h3>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <button className="flex-1 p-4 rounded-xl bg-teal-500/20 border border-teal-500/50 text-teal-400">
                <p className="font-medium">English</p>
                <p className="text-xs text-slate-500">Primary</p>
              </button>
              <button className="flex-1 p-4 rounded-xl bg-slate-800/30 border border-white/5 text-slate-400 hover:border-white/20 transition-colors">
                <p className="font-medium burmese-text">မြန်မာ</p>
                <p className="text-xs text-slate-500">Coming Soon</p>
              </button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Security */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
        <Card className="glass-card">
          <CardHeader>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Shield className="h-5 w-5 text-teal-400" />
              Security
            </h3>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button variant="outline" className="w-full border-white/10 justify-between">
              <span>Change Password</span>
              <ChevronRight className="h-4 w-4 text-slate-500" />
            </Button>
            <Button variant="outline" className="w-full border-white/10 justify-between">
              <span>Two-Factor Authentication</span>
              <Badge className="bg-slate-700 text-slate-400">Disabled</Badge>
            </Button>
            <Button variant="outline" className="w-full border-white/10 justify-between text-red-400 hover:text-red-300">
              <span>Delete Account</span>
              <ChevronRight className="h-4 w-4 text-slate-500" />
            </Button>
          </CardContent>
        </Card>
      </motion.div>

      {/* Save Button */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
        <Button className="btn-primary w-full py-6 text-lg" onClick={() => toast({ title: 'Settings saved!', description: 'Your preferences have been updated.' })}>
          <Save className="mr-2 h-5 w-5" />
          Save All Changes
        </Button>
      </motion.div>

      {/* Avatar Preview Modal */}
      <AnimatePresence>
        {previewAvatar && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
            onClick={() => setPreviewAvatar(null)}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="relative max-w-md w-full glass-card p-6 bg-slate-900"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="text-center">
                <div className="w-48 h-48 mx-auto rounded-2xl overflow-hidden border-4 border-white/10 mb-4">
                  <Image
                    src={previewAvatar.image}
                    alt={previewAvatar.name}
                    width={192}
                    height={192}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-xl font-bold text-white">{previewAvatar.name}</h3>
                <p className="text-slate-400 text-sm burmese-text">{previewAvatar.nameMm}</p>
                <p className="text-slate-500 mt-2">{previewAvatar.description}</p>
                <div className="flex gap-3 mt-6">
                  <Button variant="outline" className="flex-1 border-white/10" onClick={() => setPreviewAvatar(null)}>
                    Cancel
                  </Button>
                  <Button className="flex-1 btn-primary" onClick={() => { handleSelectAvatar(previewAvatar); setPreviewAvatar(null); }}>
                    {ownedAvatars.includes(previewAvatar.id) ? 'Equip' : `Unlock (${previewAvatar.cost} pts)`}
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
